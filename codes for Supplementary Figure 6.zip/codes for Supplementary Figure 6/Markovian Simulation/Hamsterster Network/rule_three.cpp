#include<math.h>
#include<fstream>
#include<stdlib.h>
#include"network.h"
using namespace std;

int network::trans_activity_t2_new(edge* edgep, long double(*infection_time)(long double age),int mark)
{
	int state0, state1;
	long double temp_time;
	if (node_pointer[edgep->node_num].state == 2 || node_pointer[edgep->node_num].state == 0)
	{
		if (mark == 1) edgep->b_time = network_time;
		edgep->activity = -1;
		edgep->time = -1;
		modify_edge_tree(edgep);
	}
	else
	{
		if (mark == 1) edgep->b_time = network_time;
		edgep->activity = 1;
		edgep->time = infection_time(network_time-edgep->b_time) + network_time;
		modify_edge_tree(edgep);
	}
	return 1;
}

int network::sis_trans_state_t2_new(int node_num, long double(*recovery_time)())
{
	if (node_pointer[node_num].state == 1)
	{
		node_pointer[node_num].state = 0;
		node_pointer[node_num].time = -1;
		node_infected_amount--;
		node_susceptible_amount++;
		modify_node_tree(node_num);
	}
	else if (node_pointer[node_num].state == 0)
	{
		node_pointer[node_num].state = 1;
		node_pointer[node_num].time = recovery_time() + network_time;
		node_infected_amount++;
		node_susceptible_amount--;
		modify_node_tree(node_num);
	}
	else
	{
		//		cout << "error network?asyn_sis_trans_state:state wrong!" << endl;
		return 0;
	}
	node_pointer[node_num].b_time = network_time;
	return 1;
}

int network::init_node_state_t2_new(int* infected, long double(*infection_time)(long double age), long double(*recovery_time)())
{
	int i;
	edge* edgep;
	for (i = 1; i <= infected[0]; i++)
	{
		sis_trans_state_t2_new(infected[i], recovery_time);
		edgep = node_pointer[infected[i]].first_edge_pointer;
		while (edgep)
		{
			edgep->time = infection_time(0);
			modify_edge_tree(edgep);
			edgep->b_time = network_time;
			edgep = edgep->next_edge;
		}
	}
	return 1;
}

long double network::t2_sis_spread_new(long double(*infection_time)(long double age), long double(*recovery_time)())
{
	edge* edgep;
	edge* edgepp;
	int temp_node;
	if (uncompare1(node_pointer[root_node].time, root_edge->time))
	{
		temp_node = root_node;
		network_time = node_pointer[temp_node].time;
		edgep = node_pointer[temp_node].first_edge_pointer;
		sis_trans_state_t2_new(temp_node, recovery_time);
		while (edgep)
		{
			trans_activity_t2_new(edgep, infection_time, 1);
			edgep = edgep->next_edge;
		}
	}
	else
	{
		edgepp = root_edge;
		network_time = edgepp->time;
		if (node_pointer[edgepp->target_node_num].state == 0)
		{
			sis_trans_state_t2_new(edgepp->target_node_num, recovery_time);
			edgep = node_pointer[edgepp->target_node_num].first_edge_pointer;
			while (edgep)
			{
				trans_activity_t2_new(edgep, infection_time, 1);
				edgep = edgep->next_edge;
			}
		}
		trans_activity_t2_new(edgepp, infection_time, 0);
	}
	return network_time;
}

int network::t2_sis_spread_new_mul(long double(*infection_time)(long double age), long double(*recovery_time)(), long double timestep, int len, int times, int* infected)
{
	int i, j;
	the_step = timestep;
	array_len = len;
	int temp_i;
	i_t_temp = new int[len + 1];
	p_t_average = new long double[len + 1];
	for (j = 0; j <= len; j++)
	{
		p_t_average[j] = 0;
	}
	for (i = 0; i < times; i++)
	{
		for (j = 0; j <= array_len; j++)
		{
			i_t_temp[j] = -1;
		}
		empty_all_state_new();
		init_node_state_t2_new(infected, infection_time, recovery_time);
		i_t_temp[0] = node_infected_amount;
		while (1)
		{
			t2_sis_spread_new(infection_time, recovery_time);
			//			cout << network_time << " " << node_infected_amount << endl;
			if (((int)(network_time / timestep)) + 1 > array_len) break;
			i_t_temp[((int)(network_time / timestep)) + 1] = node_infected_amount;
			if (node_infected_amount == 0) break;
		}
		temp_i = i_t_temp[0];
		for (j = 1; j <= array_len; j++)
		{
			if (i_t_temp[j] == -1) i_t_temp[j] = temp_i;
			else temp_i = i_t_temp[j];
		}
		for (j = 0; j <= array_len; j++)
		{
			p_t_average[j] += ((long double)i_t_temp[j]) / ((long double)node_amount);
		}
	}
	for (j = 0; j <= array_len; j++)
	{
		p_t_average[j] /= ((long double)times);
	}
	return 1;
}