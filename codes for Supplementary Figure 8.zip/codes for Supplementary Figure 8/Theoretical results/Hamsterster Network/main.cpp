#include"network.h"
#include<iostream>
#include<math.h>
#include<fstream>
using namespace std;

long double infect_function[604];
long double recover_function[604];
long double trans_infect_function[604];
int init_in_su(long double alpha1, long double beta1, long double alpha2, long double beta2, long double time_step)
{
	int i, j;
	for (i = 0; i < 604; i++)
	{
		if (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) == 0) infect_function[i] = 1;
		else infect_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta1, alpha1))) / pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1));
		if (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) == 0) recover_function[i] = 1;
		else recover_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta2, alpha2))) / pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2));
	}
	for (j = 0; j < 604; j++)
	{
		trans_infect_function[j] = infect_function[j];
	}
	return 1;
}
int main()
{
	int i, t;
	long double timed,temp;
	long double alpha1;
	fstream fout1("1.txt", ios::out);
	fstream fout2("2.txt", ios::out);
	fstream fout3("3.txt", ios::out);
	fstream fout4("4.txt", ios::out);
	network net(10);
	net.import_1100(1, 2426, 16631);
	net.init_array_new_pre(604);
	for (i = 1; i <= 4; i++)
	{
		if(i==1) alpha1 = 0.5;
		else if (i == 2) alpha1 = 1.0;
		else if (i == 3) alpha1 = 2.0;
		else if (i == 4) alpha1 = 4.0;
		init_in_su(alpha1, 1, 2, 0.5, 0.01);
		net.init_array_new(24.0 / 2426.0);
		timed = 0;
		t = 0;
		if (i == 1) fout1 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 2) fout2 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 3) fout3 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 4) fout4 << timed << " " << net.output_all_array_i(t) << endl;
		while (timed < 6.02)
		{
			timed += 0.01;
			t++;
			net.dynamic_rule2_new(recover_function, trans_infect_function, t);
			if (i == 1) fout1 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 2) fout2 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 3) fout3 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 4) fout4 << timed << " " << net.output_all_array_i(t) << endl;
		}
	}
	return 1;
}
