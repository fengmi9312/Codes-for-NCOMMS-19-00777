#include<iostream>
#include<math.h>
#include"network.h"
using namespace std;
int network::output_node_amount()
{
	return node_amount;
}
int network::output_node_infected_amount()
{
	return node_infected_amount;
}
long double network::output_network_time()
{
	return network_time;
}
int network::output_trans_rule1(long double(*infection_time)(), long double(*recovery_time)(),long double* function1,long double timestep,long double* s_i)
{
	int i,j;
	int possition_i;
	int possition_j;
	long double si_amount = 0;
	long double s_amount = 0;
	edge* edgep;
	long double si_temp[20000];
	long double s_temp[20000];
	for (i = 0; i < 20000; i++)
	{
		si_temp[i] = 0;
		s_temp[i] = 0;
		s_i[i] = 0;
	}
	for (j = 0; j < 10000; j++)
	{
		syn_t_sis_spread(infection_time, recovery_time, timestep);
//		cout << j << " " << node_infected_amount << endl;
		for (i = 0; i < node_amount; i++)
		{
			edgep = node_pointer[i].first_edge_pointer;
			if (node_pointer[i].state == 0)
			{
				possition_i = trans_double(network_time - node_pointer[i].b_time, 1000);
				if (possition_i < 20000) s_temp[possition_i] += 1;
			}
			s_amount += 1;
			while (edgep)
			{
				if (node_pointer[edgep->node_num].state == 1 && node_pointer[edgep->target_node_num].state == 0)
				{
					possition_i = trans_double(network_time - node_pointer[edgep->target_node_num].b_time, 1000);
					possition_j = trans_double(network_time - node_pointer[edgep->node_num].b_time, 1000);
					if (possition_i < 20000 && possition_j < 20000) si_temp[possition_i] += function1[min_i(possition_i, possition_j)];
				}
				si_amount += 1;
				edgep = edgep->next_edge;
			}
		}
	}
	for (i = 0; i < 20000; i++)
	{
		s_temp[i] /= s_amount;
		si_temp[i] /= si_amount;
		if(s_temp[i] == 0) s_i[i] = 0;
		else s_i[i] = si_temp[i] / s_temp[i];
//		if ((s_temp[i] == 0 && si_temp[i] != 0) || (s_temp[i] != 0 && si_temp[i] == 0)) system("pause");
	}
	return 1;
}
int network::output_trans_rule2(long double(*infection_time)(), long double(*recovery_time)(), long double* function1, long double timestep,long double* s_i)

{
	int i, j;
	int possition_ij;
	int possition_i;
	int possition_j;
	long double si_amount = 0;
	long double s_amount = 0;
	edge* edgep;
	long double si_temp[20000];
	long double s_temp[20000];
	for (i = 0; i < 20000; i++)
	{
		si_temp[i] = 0;
		s_temp[i] = 0;
		s_i[i] = 0;
	}
	for (j = 0; j < 10000; j++)
	{
		syn_t1_sis_spread(infection_time, recovery_time, timestep);
		for (i = 0; i < node_amount; i++)
		{
			if (node_pointer[i].state == 0)
			{
				possition_i = trans_double(network_time - node_pointer[i].b_time, 1000);
				if (possition_i < 20000) s_temp[possition_i] += 1;
			}
			s_amount += 1;
			edgep = node_pointer[i].first_edge_pointer;
			while (edgep)
			{
				if (node_pointer[edgep->node_num].state == 1 && node_pointer[edgep->target_node_num].state == 0)
				{
					possition_ij = trans_double(network_time - edgep->b_time, 1000);
					possition_j = trans_double(network_time - node_pointer[edgep->target_node_num].b_time, 1000);
					if (possition_ij < 20000 && possition_j < 20000) si_temp[possition_j] += function1[possition_ij];
				}
				si_amount += 1;
				edgep = edgep->next_edge;
			}
		}
	}
	for (i = 0; i < 20000; i++)
	{
		s_temp[i] /= s_amount;
		si_temp[i] /= si_amount;
		if (s_temp[i] == 0) s_i[i] = 0;
		else s_i[i] = si_temp[i] / s_temp[i];
//		if ((s_temp[i] == 0 && si_temp[i] != 0) || (s_temp[i] != 0 && si_temp[i] == 0)) system("pause");
	}
	return 1;
}
long double network::output_lost_rule1(long double(*infection_time)(), long double(*recovery_time)(), long double* function1, long double* function2, long double* function3,long double degree,long double& i_density,long double timestep)
{
	int i, j;
	int times = 10000;
	int possition_i;
	int possition_j;
	long double si_amount = 0;
	edge* edgep;
	long double temp = 0;
	i_density = 0;
	for (j = 0; j < times; j++)
	{
		syn_t_sis_spread(infection_time, recovery_time, timestep);
		if (node_infected_amount == 0)
		{
			i_density = 0;
			return 0;
		}
		i_density += ((long double)node_infected_amount) / ((long double)node_amount);
		for (i = 0; i < node_amount; i++)
		{
			edgep = node_pointer[i].first_edge_pointer;
			while (edgep)
			{
				if (node_pointer[edgep->node_num].state == 1 && node_pointer[edgep->target_node_num].state == 0)
				{
					possition_i = trans_double(network_time - node_pointer[edgep->target_node_num].b_time, 1000);
					possition_j = trans_double(network_time - node_pointer[edgep->node_num].b_time, 1000);
					if (possition_i < 20000 && possition_j < 20000)
					{
						temp += function1[min_i(possition_i, possition_j)] - function3[possition_i];
						si_amount += function2[possition_j] + function1[min_i(possition_i, possition_j)] + (degree - 1)*function3[possition_i];
					}
				}
				edgep = edgep->next_edge;
			}
		}
	}
	i_density /= ((long double)times);
	return temp / si_amount;
}
long double network::output_lost_rule2(long double(*infection_time)(), long double(*recovery_time)(), long double* function1, long double* function2, long double* function3, long double degree, long double& i_density, long double timestep)
{
	int i, j;
	int times = 10000;
	int possition_i;
	int possition_j;
	int possition_ij;
	long double si_amount = 0;
	edge* edgep;
	long double temp = 0;
	i_density = 0;
	for (j = 0; j < times; j++)
	{
		syn_t1_sis_spread(infection_time, recovery_time, timestep);
		if (node_amount == 0)
		{
			i_density = 0;
			return 0;
		}
		i_density += ((long double)node_infected_amount) / ((long double)node_amount);
		for (i = 0; i < node_amount; i++)
		{
			edgep = node_pointer[i].first_edge_pointer;
			while (edgep)
			{
				if (node_pointer[edgep->node_num].state == 1 && node_pointer[edgep->target_node_num].state == 0)
				{
					possition_i = trans_double(network_time - node_pointer[edgep->target_node_num].b_time, 1000);
					possition_j = trans_double(network_time - node_pointer[edgep->node_num].b_time, 1000);
					possition_ij = trans_double(network_time - edgep->b_time, 1000);
					if (possition_i < 20000 && possition_j < 20000 && possition_ij < 20000)
					{
						temp += function1[possition_ij];
						si_amount += function2[possition_j] + function1[possition_ij] + (degree - 1)*function3[possition_i];
					}
				}
				edgep = edgep->next_edge;
			}
		}
	}
	i_density /= ((long double)times);
	return temp / si_amount;
}




long double aa1 = 0, bb1 = 0, aa2 = 0, bb2 = 0;
long double infection_()
{
	return bb1 * pow((log(100000.0) - log((long double)outputfrandnum(100000))) / log(2.718), 1 / aa1);
}

long double recovery_()
{
	return bb2 * pow((log(100000.0) - log((long double)outputfrandnum(100000))) / log(2.718), 1 / aa2);
}


long double network::output_all_num_d()
{
	long double temp;
	int i;
	temp = 0;
	for (i = 0; i < node_amount; i++)
	{
		temp += node_pointer[i].num_d;
	}
	temp /= ((long double)node_amount);
	return temp;
}


long double network::output_e_time(int node_num, int state)
{
	if (node_pointer[node_num].state == state) return network_time - node_pointer[node_num].b_time;
	else return -1;
}

int network::output_mark(int node_num, int state)
{
	if (state==0) return node_pointer[node_num].s_birth_mark;
	else if(state=1) return node_pointer[node_num].i_birth_mark;
	else return 0;
}