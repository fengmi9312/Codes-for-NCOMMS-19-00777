#include<math.h>
#include<fstream>
#include<stdlib.h>
#include"network.h"
using namespace std;
int network::init_node_tree()
{
	int i = 0;
	root_node = i;
	while (1)
	{
		if (i * 2 + 1 >= node_amount) break;
		node_pointer[i].left_child = i * 2 + 1;
		node_pointer[i * 2 + 1].father = i;
		if (i * 2 + 2 >= node_amount) break;
		node_pointer[i].right_child = i * 2 + 2;
		node_pointer[i * 2 + 2].father = i;
		i++;
	}
	return 1;
}
int network::init_edge_tree()
{
	edge** edge_temp;
	edge_temp = new edge*[edge_amount * 2];
	int i,j;
	edge* edgep;
	j = 0;
	root_edge = node_pointer[0].first_edge_pointer;
	for (i = 0; i < node_amount; i++)
	{
		edgep = node_pointer[i].first_edge_pointer;
		while (edgep)
		{
			edge_temp[j] = edgep;
			j++;
			edgep = edgep->next_edge;
		}
	}
	i = 0;
	while (1)
	{
		if (i * 2 + 1 >= edge_amount*2) break;
		edge_temp[i]->left_child = edge_temp[i * 2 + 1];
		edge_temp[i * 2 + 1]->father = edge_temp[i];
		if (i * 2 + 2 >= edge_amount*2) break;
		edge_temp[i]->right_child = edge_temp[i * 2 + 2];
		edge_temp[i * 2 + 2]->father = edge_temp[i];
		i++;
	}
	return 1;
}
int network::judge_node_tree(int node_num)
{
	int judge[3];
	if (node_pointer[node_num].father == -1 || uncompare1(node_pointer[node_pointer[node_num].father].time, node_pointer[node_num].time)) judge[0] = 0;
	else if ((!uncompare1(node_pointer[node_pointer[node_num].father].time, node_pointer[node_num].time)) && node_pointer[node_pointer[node_num].father].left_child == node_num) judge[0] = 1;
	else if ((!uncompare1(node_pointer[node_pointer[node_num].father].time, node_pointer[node_num].time)) && node_pointer[node_pointer[node_num].father].right_child == node_num) judge[0] = 2;
	else return -1;
	if (node_pointer[node_num].left_child == -1 || (!uncompare(node_pointer[node_pointer[node_num].left_child].time, node_pointer[node_num].time))) judge[1] = 0;
	else if (uncompare(node_pointer[node_pointer[node_num].left_child].time, node_pointer[node_num].time)) judge[1] = 1; 
	else return -1;
	if (node_pointer[node_num].right_child == -1 || (!uncompare(node_pointer[node_pointer[node_num].right_child].time, node_pointer[node_num].time))) judge[2] = 0;
	else if (uncompare(node_pointer[node_pointer[node_num].right_child].time, node_pointer[node_num].time)) judge[2] = 1;
	else return -1;
	if (judge[0] == 0 && judge[1] == 0 && judge[2] == 0) return 0;
	else if (judge[0] == 1 && judge[1] == 0 && judge[2] == 0) return 1;
	else if (judge[0] == 2 && judge[1] == 0 && judge[2] == 0) return 2;
	else if (judge[0] == 0 && judge[1] == 1 && judge[2] == 0) return 3;
	else if (judge[0] == 0 && judge[1] == 1 && judge[2] == 1) 
	{
		if (uncompare(node_pointer[node_pointer[node_num].left_child].time, node_pointer[node_pointer[node_num].right_child].time)) return 3;
		else return 4;
	} 
	else if (judge[0] == 0 && judge[1] == 0 && judge[2] == 1) return 4;
	else
	{
		return -1;
	}
}
int network::move_node_tree_left(int top_num)
{
	int temp_top[3];
	int temp_bottom[3];
	int left_bottom;
	left_bottom = node_pointer[top_num].left_child;
	temp_top[0] = node_pointer[top_num].father;
	temp_top[1] = node_pointer[top_num].left_child;
	temp_top[2] = node_pointer[top_num].right_child;
	temp_bottom[0] = node_pointer[left_bottom].father;
	temp_bottom[1] = node_pointer[left_bottom].left_child;
	temp_bottom[2] = node_pointer[left_bottom].right_child;
	node_pointer[top_num].father = left_bottom;
	node_pointer[left_bottom].left_child = top_num;
	node_pointer[top_num].left_child = temp_bottom[1];
	node_pointer[top_num].right_child = temp_bottom[2];
	node_pointer[left_bottom].father = temp_top[0];
	node_pointer[left_bottom].right_child = temp_top[2];
	if (node_pointer[left_bottom].father != -1)
	{
		if (node_pointer[node_pointer[left_bottom].father].left_child == top_num) node_pointer[node_pointer[left_bottom].father].left_child = left_bottom;
		else if (node_pointer[node_pointer[left_bottom].father].right_child == top_num)  node_pointer[node_pointer[left_bottom].father].right_child = left_bottom;
		else cout << "error move_node_tree_left 0" << endl;
	}
	if (node_pointer[left_bottom].right_child != -1)
	{
		if (node_pointer[node_pointer[left_bottom].right_child].father == top_num) node_pointer[node_pointer[left_bottom].right_child].father = left_bottom;
		else cout << "error move_node_tree_left 0" << endl;
	}
	if (node_pointer[top_num].left_child != -1)
	{
		if (node_pointer[node_pointer[top_num].left_child].father == left_bottom) node_pointer[node_pointer[top_num].left_child].father = top_num;
		else cout << "error move_node_tree_left 1" << endl;
	}
	if (node_pointer[top_num].right_child != -1)
	{
		if (node_pointer[node_pointer[top_num].right_child].father == left_bottom) node_pointer[node_pointer[top_num].right_child].father = top_num;
		else cout << "error move_node_tree_left 2" << endl;
	}
	if (node_pointer[top_num].father == -1) root_node = top_num;
	if (node_pointer[left_bottom].father == -1) root_node = left_bottom;
//	check_node_tree(0);
	return 1;
}
int network::move_node_tree_right(int top_num)
{
	int temp_top[3];
	int temp_bottom[3];
	int right_bottom;
	right_bottom = node_pointer[top_num].right_child;
	temp_top[0] = node_pointer[top_num].father;
	temp_top[1] = node_pointer[top_num].left_child;
	temp_top[2] = node_pointer[top_num].right_child;
	temp_bottom[0] = node_pointer[right_bottom].father;
	temp_bottom[1] = node_pointer[right_bottom].left_child;
	temp_bottom[2] = node_pointer[right_bottom].right_child;
	node_pointer[top_num].father = right_bottom;
	node_pointer[right_bottom].right_child = top_num;
	node_pointer[top_num].left_child = temp_bottom[1];
	node_pointer[top_num].right_child = temp_bottom[2];
	node_pointer[right_bottom].father = temp_top[0];
	node_pointer[right_bottom].left_child = temp_top[1];
	if (node_pointer[right_bottom].father != -1)
	{
		if (node_pointer[node_pointer[right_bottom].father].left_child == top_num) node_pointer[node_pointer[right_bottom].father].left_child = right_bottom;
		else if (node_pointer[node_pointer[right_bottom].father].right_child == top_num)  node_pointer[node_pointer[right_bottom].father].right_child = right_bottom;
		else cout << "error move_node_tree_right 0" << endl;
	}
	if (node_pointer[right_bottom].left_child != -1)
	{
		if (node_pointer[node_pointer[right_bottom].left_child].father == top_num) node_pointer[node_pointer[right_bottom].left_child].father = right_bottom;
		else cout << "error move_node_tree_left 0" << endl;
	}
	if (node_pointer[top_num].left_child != -1)
	{
		if (node_pointer[node_pointer[top_num].left_child].father == right_bottom) node_pointer[node_pointer[top_num].left_child].father = top_num;
		else cout << "error move_node_tree_right 1" << endl;
	}
	if (node_pointer[top_num].right_child != -1)
	{
		if (node_pointer[node_pointer[top_num].right_child].father == right_bottom) node_pointer[node_pointer[top_num].right_child].father = top_num;
		else cout << "error move_node_tree_right 2" << endl;
	}
	if (node_pointer[top_num].father == -1) root_node = top_num;
	if (node_pointer[right_bottom].father == -1) root_node = right_bottom;
//	check_node_tree(1);
	return 1;
}
int network::modify_node_tree(int node_num)
{
	int judge_num;
	while (1)
	{
		judge_num = judge_node_tree(node_num);
		if (judge_num == 0) break;
		else if (judge_num == 1) move_node_tree_left(node_pointer[node_num].father);
		else if (judge_num == 2) move_node_tree_right(node_pointer[node_num].father);
		else if (judge_num == 3) move_node_tree_left(node_num);
		else if (judge_num == 4) move_node_tree_right(node_num);
		else
		{
			cout << "error modify_node_tree" << endl;
			return -1;
		}
	}
//	check_node_time_tree();
	return 1;
}
int network::judge_edge_tree(edge* edgep)
{
	int judge[3];
	if (edgep->father == NULL || uncompare1(edgep->father->time, edgep->time)) judge[0] = 0;
	else if ((!uncompare1(edgep->father->time, edgep->time)) && edgep->father->left_child == edgep) judge[0] = 1;
	else if ((!uncompare1(edgep->father->time, edgep->time)) && edgep->father->right_child == edgep) judge[0] = 2;
	else return -1;
	if (edgep->left_child == NULL || (!uncompare(edgep->left_child->time, edgep->time))) judge[1] = 0;
	else if (uncompare(edgep->left_child->time, edgep->time)) judge[1] = 1;
	else return -1;
	if (edgep->right_child == NULL || (!uncompare(edgep->right_child->time, edgep->time))) judge[2] = 0;
	else if (uncompare(edgep->right_child->time, edgep->time)) judge[2] = 1;
	else return -1;
	if (judge[0] == 0 && judge[1] == 0 && judge[2] == 0) return 0;
	else if (judge[0] == 1 && judge[1] == 0 && judge[2] == 0) return 1;
	else if (judge[0] == 2 && judge[1] == 0 && judge[2] == 0) return 2;
	else if (judge[0] == 0 && judge[1] == 1 && judge[2] == 0) return 3;
	else if (judge[0] == 0 && judge[1] == 1 && judge[2] == 1)
	{
		if(uncompare(edgep->left_child->time,edgep->right_child->time)) return 3;
		else return 4;
	}
	else if (judge[0] == 0 && judge[1] == 0 && judge[2] == 1) return 4;
	else return -1;
}
int network::move_edge_tree_left(edge* top_edgep)
{
	edge* temp_top[3];
	edge* temp_bottom[3];
	edge* left_bottom;
	left_bottom = top_edgep->left_child;
	temp_top[0] = top_edgep->father;
	temp_top[1] = top_edgep->left_child;
	temp_top[2] = top_edgep->right_child;
	temp_bottom[0] = left_bottom->father;
	temp_bottom[1] = left_bottom->left_child;
	temp_bottom[2] = left_bottom->right_child;
	top_edgep->father = left_bottom;
	left_bottom->left_child = top_edgep;
	top_edgep->left_child = temp_bottom[1];
	top_edgep->right_child = temp_bottom[2];
	left_bottom->father = temp_top[0];
	left_bottom->right_child = temp_top[2];
	if (left_bottom->father != NULL)
	{
		if (left_bottom->father->left_child == top_edgep) left_bottom->father->left_child = left_bottom;
		else if (left_bottom->father->right_child == top_edgep) left_bottom->father->right_child = left_bottom;
		else cout << "error move_edge_tree_left 0" << endl;
	}
	if (left_bottom->right_child != NULL)
	{
		if (left_bottom->right_child->father == top_edgep) left_bottom->right_child->father = left_bottom;
		else cout << "error move_edge_tree_left 1" << endl;
	}
	if (top_edgep->left_child != NULL)
	{
		if (top_edgep->left_child->father == left_bottom) top_edgep->left_child->father = top_edgep;
		else cout << "error move_edge_tree_left 1" << endl;
	}
	if (top_edgep->right_child != NULL)
	{
		if (top_edgep->right_child->father == left_bottom) top_edgep->right_child->father = top_edgep;
		else cout << "error move_edge_tree_left 2" << endl;
	}
	if (top_edgep->father == NULL) root_edge = top_edgep;
	if (left_bottom->father == NULL) root_edge = left_bottom;
//	check_edge_tree(0);
//	check_edge_time_tree();
	return 1;
}
int network::move_edge_tree_right(edge* top_edgep)
{
	edge* temp_top[3];
	edge* temp_bottom[3];
	edge* right_bottom;
	right_bottom = top_edgep->right_child;
	temp_top[0] = top_edgep->father;
	temp_top[1] = top_edgep->left_child;
	temp_top[2] = top_edgep->right_child;
	temp_bottom[0] = right_bottom->father;
	temp_bottom[1] = right_bottom->left_child;
	temp_bottom[2] = right_bottom->right_child;
	top_edgep->father = right_bottom;
	right_bottom->right_child = top_edgep;
	top_edgep->left_child = temp_bottom[1];
	top_edgep->right_child = temp_bottom[2];
	right_bottom->father = temp_top[0];
	right_bottom->left_child = temp_top[1];
	if (right_bottom->father != NULL)
	{
		if (right_bottom->father->left_child == top_edgep) right_bottom->father->left_child = right_bottom;
		else if (right_bottom->father->right_child == top_edgep) right_bottom->father->right_child = right_bottom;
		else cout << "error move_edge_tree_right 0" << endl;
	}
	if (right_bottom->left_child != NULL)
	{
		if (right_bottom->left_child->father == top_edgep) right_bottom->left_child->father = right_bottom;
		else cout << "error move_edge_tree_left 1" << endl;
	}
	if (top_edgep->left_child != NULL)
	{
		if (top_edgep->left_child->father == right_bottom) top_edgep->left_child->father = top_edgep;
		else cout << "error move_edge_tree_right 1" << endl;
	}
	if (top_edgep->right_child != NULL)
	{
		if (top_edgep->right_child->father == right_bottom) top_edgep->right_child->father = top_edgep;
		else cout << "error move_edge_tree_right 2" << endl;
	}
	if (top_edgep->father == NULL) root_edge = top_edgep;
	if (right_bottom->father == NULL) root_edge = right_bottom;
	//check_edge_tree(1);
	return 1;
}
int network::modify_edge_tree(edge* edgep)
{

	int judge_num;
	while (1)
	{
		judge_num = judge_edge_tree(edgep);
		if (judge_num == 0) break;
		else if (judge_num == 1) move_edge_tree_left(edgep->father);
		else if (judge_num == 2) move_edge_tree_right(edgep->father);
		else if (judge_num == 3) move_edge_tree_left(edgep);
		else if (judge_num == 4) move_edge_tree_right(edgep);
		else
		{
			cout << "error modify_edge_tree" << endl;
			return -1;
		}
	}
//	check_edge_tree(1);
//	check_edge_time_tree();
	return 1;
}
int network::trans_activity_t_new(edge* edgep, long double(*infection_time)())
{
	int state0, state1;
	long double temp_time;
	state0 = node_pointer[edgep->node_num].state;
	state1 = node_pointer[edgep->target_node_num].state;
	if (state0 == 2 || state1 == 2)
	{
		edgep->activity = -1;
		edgep->time = -1;
		modify_edge_tree(edgep);
		edgep->brother_edge->activity = -1;
		edgep->brother_edge->time = -1;
		modify_edge_tree(edgep->brother_edge);
	}
	else if ((state0 == 0 && state1 == 0) || (state0 == 1 && state1 == 1))
	{
		edgep->activity = 0;
		edgep->time = -1;
		modify_edge_tree(edgep);
		edgep->brother_edge->activity = 0;
		edgep->brother_edge->time = -1;
		modify_edge_tree(edgep->brother_edge);
	}
	else if ((state0 == 0 && state1 == 1) || (state0 == 1 && state1 == 0))
	{
		temp_time = infection_time() + network_time;
		if (state0 == 1 && state1 == 0)
		{
			edgep->activity = 1;
			edgep->brother_edge->activity = 0;
			edgep->time = temp_time;
			modify_edge_tree(edgep);
			edgep->brother_edge->time = -1;
			modify_edge_tree(edgep->brother_edge);
		}
		else
		{
			edgep->activity = 0;
			edgep->brother_edge->activity = 1;
			edgep->time = -1;
			modify_edge_tree(edgep);
			edgep->brother_edge->time = temp_time;
			modify_edge_tree(edgep->brother_edge);
		}
	}
	edgep->b_time = network_time;
	return 1;
}
int network::trans_activity_t1_new(edge* edgep, long double(*infection_time)())
{
	int state0, state1;
	long double temp_time;
	if (node_pointer[edgep->node_num].state == 2 || node_pointer[edgep->node_num].state == 0)
	{
		edgep->activity = -1;
		edgep->time = -1;
		modify_edge_tree(edgep);
	}
	else
	{
		edgep->activity = 1;
		edgep->time = infection_time() + network_time;
		modify_edge_tree(edgep);
	}
	edgep->b_time = network_time;
	return 1;
}
int network::empty_all_state_new()
{
	int i;
	edge* edgep;
	for (i = 0; i<node_amount; i++)
	{
		node_pointer[i].state = 0;
		node_pointer[i].time = -1;
		node_pointer[i].b_time = 0;
		node_pointer[i].father = -1;
		node_pointer[i].left_child = -1;
		node_pointer[i].right_child = -1;
		edgep = node_pointer[i].first_edge_pointer;
		while (edgep)
		{
			edgep->father = NULL;
			edgep->left_child = NULL;
			edgep->right_child = NULL;
			edgep->activity = 0;
			edgep->time = -1;
			edgep->b_time = 0;
			edgep = edgep->next_edge;
		}
	}
	node_infected_amount = 0;
	node_susceptible_amount = node_amount;
	network_time = 0;
	init_node_tree();
	init_edge_tree();
	return 1;
}
int network::sis_trans_state_t_new(int node_num, long double(*infection_time)(), long double(*recovery_time)())
{
	edge* edgep0 = node_pointer[node_num].first_edge_pointer;
	if (node_pointer[node_num].state == 1)
	{
		node_pointer[node_num].state = 0;
		node_pointer[node_num].time = -1;
		node_infected_amount--;
		node_susceptible_amount++;
		modify_node_tree(node_num);
	}
	else if (node_pointer[node_num].state == 0)
	{
		node_pointer[node_num].state = 1;
		node_pointer[node_num].time = recovery_time() + network_time;
		node_infected_amount++;
		node_susceptible_amount--;
		modify_node_tree(node_num);
	}
	else
	{
		//		cout<<"error network?asyn_sis_trans_state:state wrong!"<<endl;
		return 0;
	}
	node_pointer[node_num].b_time = network_time;
	while (edgep0)
	{
		trans_activity_t_new(edgep0, infection_time);
		edgep0 = edgep0->next_edge;
	}
	return 1;
}
int network::sis_trans_state_t1_new(int node_num, long double(*recovery_time)())
{
	if (node_pointer[node_num].state == 1)
	{
		node_pointer[node_num].state = 0;
		node_pointer[node_num].time = -1;
		node_infected_amount--;
		node_susceptible_amount++;
		modify_node_tree(node_num);
	}
	else if (node_pointer[node_num].state == 0)
	{
		node_pointer[node_num].state = 1;
		node_pointer[node_num].time = recovery_time() + network_time;
		node_infected_amount++;
		node_susceptible_amount--;
		modify_node_tree(node_num);
	}
	else
	{
		//		cout << "error network?asyn_sis_trans_state:state wrong!" << endl;
		return 0;
	}
	node_pointer[node_num].b_time = network_time;
	return 1;
}
int network::init_node_state_t_new(int* infected, long double(*infection_time)(), long double(*recovery_time)())
{
	int i;
	for (i = 1; i <= infected[0]; i++)
	{
		sis_trans_state_t_new(infected[i], infection_time, recovery_time);
//		cout << i << endl;

//		output();
//		node_pointer[infected[i]].time = recovery_time();
//		modify_node_tree(infected[i]);
//		edgep = node_pointer[infected[i]].first_edge_pointer;
//		while (edgep)
//		{
//			if (edgep->activity == 1) edgep->time = infection_time();
//			modify_edge_tree(edgep);
	//		edgep = edgep->next_edge;
	//	}
	}
	return 1;
}
int network::init_node_state_t1_new(int* infected, long double(*infection_time)(), long double(*recovery_time)())
{
	int i;
	edge* edgep;
	for (i = 1; i <= infected[0]; i++)
	{
		sis_trans_state_t1_new(infected[i], recovery_time);
		edgep = node_pointer[infected[i]].first_edge_pointer;
		while (edgep)
		{
			edgep->time = infection_time();
			modify_edge_tree(edgep);
			edgep->b_time = network_time;
			edgep = edgep->next_edge;
		}
	}
	return 1;
}
long double network::t_sis_spread_new(long double(*infection_time)(), long double(*recovery_time)())
{
	int temp_node;
	edge* edgepp;
	if (uncompare1(node_pointer[root_node].time, root_edge->time))
	{
		temp_node = root_node;
		network_time = node_pointer[temp_node].time;
		sis_trans_state_t_new(temp_node, infection_time, recovery_time);
	}
	else
	{
		edgepp = root_edge;
		network_time = edgepp->time;
		sis_trans_state_t_new(edgepp->target_node_num, infection_time, recovery_time);
	}
	return network_time;
}
long double network::t1_sis_spread_new(long double(*infection_time)(), long double(*recovery_time)())
{
	edge* edgep;
	edge* edgepp;
	int temp_node;
	if (uncompare1(node_pointer[root_node].time, root_edge->time))
	{
		temp_node = root_node;
		network_time = node_pointer[temp_node].time;
		edgep = node_pointer[temp_node].first_edge_pointer;
		sis_trans_state_t1_new(temp_node, recovery_time);
		while (edgep)
		{
			trans_activity_t1_new(edgep, infection_time);
			edgep = edgep->next_edge;
		}
	}
	else
	{
		edgepp = root_edge;
		network_time = edgepp->time;
		if (node_pointer[edgepp->target_node_num].state == 0)
		{
			sis_trans_state_t1_new(edgepp->target_node_num, recovery_time); 
			edgep = node_pointer[edgepp->target_node_num].first_edge_pointer;
			while (edgep)
			{
				trans_activity_t1_new(edgep, infection_time);
				edgep = edgep->next_edge;
			}
		}
		trans_activity_t1_new(edgepp, infection_time);
	}
	return network_time;
}
int network::check_node_tree(int p)
{
	int i;
	for (i = 0; i < node_amount; i++)
	{
		if (node_pointer[i].left_child != -1)
		{
			if (node_pointer[node_pointer[i].left_child].father != i)
				cout <<p<< " error check" << endl;
		}
		if (node_pointer[i].right_child != -1)
		{
			if (node_pointer[node_pointer[i].right_child].father != i)
				cout << p << " error chech" << endl;
		}
	}
	return 1;
}
int network::check_edge_tree(int p)
{
	int i;
	edge* edgep;
	for (i = 0; i < node_amount; i++)
	{
		edgep = node_pointer[i].first_edge_pointer;
		while (edgep)
		{
			if (edgep->left_child != NULL)
			{
				if (edgep->left_child->father != edgep)
					cout << p << "edge error check" << endl;
			}
			if (edgep->right_child != NULL)
			{
				if (edgep->right_child->father != edgep)
				    cout << p << "edge error check" << endl;
			}
			edgep = edgep->next_edge;
		}
	}
	return 1;
}
int network::check_node_time_tree()
{
	int i;
	for (i = 0; i < node_amount; i++)
	{
		if(node_pointer[i].father!=-1)
		if (uncompare(node_pointer[i].time, node_pointer[node_pointer[i].father].time))
			cout << "error" << " " << i << " and father:" << node_pointer[i].father << endl; 
		if (node_pointer[i].left_child != -1)
		if (uncompare(node_pointer[node_pointer[i].left_child].time, node_pointer[i].time))
			cout << "error" << " " << i << " and left_child:" << node_pointer[i].left_child << endl;
		if (node_pointer[i].right_child != -1)
		if (uncompare(node_pointer[node_pointer[i].right_child].time,node_pointer[i].time))
			cout << "error" << " " << i << " and right_child:" << node_pointer[i].right_child << endl;
	}
	return 1;
}
int network::check_edge_time_tree()
{
	int i;
	edge* edgep;
	for (i = 0; i < node_amount; i++)
	{ 
		edgep = node_pointer[i].first_edge_pointer;
		while (edgep)
		{
			if (edgep->father != NULL)
				if (uncompare(edgep->time, edgep->father->time))
					cout << "error_edge" << endl;
			if (edgep->left_child != NULL)
				if (uncompare(edgep->left_child->time, edgep->time))
					cout << "error_edge" << endl;
			if (edgep->right_child != NULL)
				if (uncompare(edgep->right_child->time, edgep->time))
					cout << "error_edge" << endl;
			edgep = edgep->next_edge;
		}
	}
	return 1;
}
int network::t_sis_spread_new_mul(long double(*infection_time)(), long double(*recovery_time)(), long double timestep, int len, int times, int* infected)
{
	int i, j;
	the_step = timestep;
	array_len = len;
	int temp_i;
	i_t_temp = new int[len+1];
	p_t_average = new long double[len+1]; 
	for (j = 0; j <= len; j++)
	{
		p_t_average[j] = 0;
	}
	for (i = 0; i < times; i++)
	{
		for (j = 0; j <= array_len; j++)
		{
			i_t_temp[j] = -1;
		}
		empty_all_state_new();
		init_node_state_t_new(infected, infection_time, recovery_time);
		i_t_temp[0] = node_infected_amount;
		while (1)
		{
			t_sis_spread_new(infection_time, recovery_time);
			if (((int)(network_time / timestep)) + 1 > array_len) break;
			i_t_temp[((int)(network_time / timestep)) + 1] = node_infected_amount;
			if (node_infected_amount == 0) break;
		}
		temp_i = i_t_temp[0];
		for (j = 1; j <= array_len; j++)
		{
			if (i_t_temp[j] == -1) i_t_temp[j] = temp_i;
			else temp_i = i_t_temp[j];
		}
		for (j = 0; j <= array_len; j++)
		{
			p_t_average[j] += ((long double)i_t_temp[j]) / ((long double)node_amount);
		}
	}
	for (j = 0; j <= array_len; j++)
	{
		p_t_average[j] /= ((long double)times);
	}
	return 1;
}
int network::t1_sis_spread_new_mul(long double(*infection_time)(), long double(*recovery_time)(), long double timestep, int len, int times, int* infected)
{
	int i, j;
	the_step = timestep;
	array_len = len;
	int temp_i;
	i_t_temp = new int[len + 1];
	p_t_average = new long double[len + 1];
	for (j = 0; j <= len; j++)
	{
		p_t_average[j] = 0;
	}
	for (i = 0; i < times; i++)
	{
		for (j = 0; j <= array_len; j++)
		{
			i_t_temp[j] = -1;
		}
		empty_all_state_new();
		init_node_state_t1_new(infected, infection_time, recovery_time);
		i_t_temp[0] = node_infected_amount;
		while (1)
		{
			t1_sis_spread_new(infection_time, recovery_time);
//			cout << network_time << " " << node_infected_amount << endl;
			if (((int)(network_time / timestep)) + 1 > array_len) break;
			i_t_temp[((int)(network_time / timestep)) + 1] = node_infected_amount;
			if (node_infected_amount == 0) break;
		}
		temp_i = i_t_temp[0];
		for (j = 1; j <= array_len; j++)
		{
			if (i_t_temp[j] == -1) i_t_temp[j] = temp_i;
			else temp_i = i_t_temp[j];
		}
		for (j = 0; j <= array_len; j++)
		{
			p_t_average[j] += ((long double)i_t_temp[j]) / ((long double)node_amount);
		}
	}
	for (j = 0; j <= array_len; j++)
	{
		p_t_average[j] /= ((long double)times);
	}
	return 1;
}
long double* network::output_new_p_t(int &len, long double &timestep)
{
	int i;
	long double* temp;
	temp = new long double[array_len + 1];
	for (i = 0; i <= array_len; i++)
	{
		temp[i] = p_t_average[i];
	}
	len = array_len;
	timestep = the_step;
	return temp;
}