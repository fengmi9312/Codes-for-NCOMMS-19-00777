#include<iostream>
#include<math.h>
#include<fstream>
#include<stdlib.h>
#include"network.h"
using namespace std;
int uncompare(long double x,long double y)//if x>=y,return 0,else return 1;
{
	if(x==-1) return 0;
	else if(x>=0&&y==-1) return 1;
	else if(x>=y) return 0;
	else if(x<y) return 1;
}
int uncompare1(long double x,long double y)//if x>y,return 0,else return 1;
{
	if(x==-1) return 0;
	else if(x>=0&&y==-1) return 1;
	else if(x>y) return 0;
	else if(x<=y) return 1;
}
int min_i(int x, int y)
{
	if (x < y) return x;
	else return y;
}
long long int ipow(int x,int y)
{
	int i;
	long long int powx=1;
	for(i=0;i<y;i++)
	{
		powx=powx*x;
	}
	return powx;
}
int ilog(long long int x,long long int y)
{
	if(x<=0||y<=0)
	{
//		cout<<"error network?ilog:: x or y blow or equal 0!"<<endl;
		return -1;
	}
	long long int temp;
	int i=0;
	temp=x;
	while(temp<=y)
	{
	    temp=temp*x;
		i++;
	}
	return i;
}
long long int outputfrandnum(long long int max)
{
	int i;
	int length;
    long long int num;
	if(max<=0) return -1;
	length=ilog(2,max)+1;
	do
	{
		num=0;
        for(i=0;i<length;i++)
	    {
    	     num=num*2+rand()%2;
    	}
	}while(num>=max);
	return num;
}
int fpossibility(long double rand,long long int acc)
{
	long long int randint;
	long long int num;
	num=outputfrandnum(acc);
	randint=(long long int)(rand*(long double)acc);
	if(num<=randint) return 1;
	else return 0;
}


int trans_double(long double num, long double step)
{
	int temp1;
	int temp2;
	long double temp11;
	long double temp22;
	temp1 = (int)(num*step);
	temp2 = temp1 + 1;
	temp11 = (long double)temp1;
	temp22 = (long double)temp2;
	if (num >= temp11 + 0.5) return temp2;
	else return temp1;
}


long double density_rule_one(long double alpha1, long double beta1, long double alpha2, long double beta2, long double density, long double degree)
{
	int i, j;
	long double infect_function[6001];
	long double un_recover_function[6001];
	long double temp1, temp2;
	long double lamda_infect_function[6001];
	long double time_step = 0.001;
	long double eff_recover;
	long double fenmu = 0;
	eff_recover = alpha2 / (beta2*tgammal(1 / alpha2));
	for (i = 0; i < 6001; i++)
	{
		if (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) == 0) infect_function[i] = 1;
		else infect_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta1, alpha1))) / pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1));
		un_recover_function[i] = pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2));
	}
	temp1 = 0;
	temp2 = 0;
	for (i = 0; i < 6001; i++) temp2 += un_recover_function[i];
	for (i = 0; i < 6001; i++)
	{
		temp1 += infect_function[i] * un_recover_function[i];
		temp2 -= un_recover_function[i];
		if (i == 0) lamda_infect_function[i] = (temp1 + temp2*infect_function[i])*time_step*eff_recover;
		else lamda_infect_function[i] = lamda_infect_function[i - 1] + (temp1 + temp2*infect_function[i])*time_step*eff_recover;
	}
	for (i = 0; i < 6001; i++) fenmu += pow(2.718, -lamda_infect_function[i] * degree*density)*time_step;
	return (1 - density) / fenmu / eff_recover;
}

long double density_rule_two(long double alpha1, long double beta1, long double alpha2, long double beta2, long double density, long double degree)
{
	int i, j;
	long double infect_function[6001];
	long double un_recover_function[6001];
	long double trans_infect_function[6001];
	long double time_step = 0.001;
	long double eff_infect = 0;
	for (i = 0; i < 6001; i++)
	{
		if (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) == 0) infect_function[i] = 1;
		else infect_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta1, alpha1))) / pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1));
		un_recover_function[i] = pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2));
	}
	for (j = 0; j < 6001; j++)
	{
		trans_infect_function[j] = pow(2.718, -pow(((long double)j)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(j + 1))*time_step / beta1, alpha1));
		for (i = 0; i < j; i++)
		{
			trans_infect_function[j] += trans_infect_function[i] * (pow(2.718, -pow(((long double)(j - i - 1))*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(j - i))*time_step / beta1, alpha1)));
		}
	}
	for (i = 0; i < 6001; i++)
	{
		eff_infect += un_recover_function[i] * trans_infect_function[i];
	}
	return eff_infect*(1 - density)*density*degree;
}
long double find_out_beta1(long double alpha1, long double alpha2, long double beta2, long double head, long double tail, long double density, long double degree, int rule)
{
	long double temp;
	if (rule == 1) temp = density_rule_one(alpha1, (head + tail) / 2, alpha2, beta2, density, degree);
	else temp = density_rule_two(alpha1, (head + tail) / 2, alpha2, beta2, density, degree);
//	cout << head << " " << tail << " " << temp << endl;
	if (temp < density - 0.0001) return find_out_beta1(alpha1, alpha2, beta2, head, (head + tail) / 2, density, degree, rule);
	else if (temp > density + 0.0001) return find_out_beta1(alpha1, alpha2, beta2, (head + tail) / 2, tail, density, degree, rule);
	else return (head + tail) / 2;
}
long double find_beta1(long double alpha1, long double alpha2, long double beta2, long double density, long double degree, int rule)
{
	long double beta1_temp = 10;
	long double last_temp;
	long double temp_exchange;
	long double density_temp;
	int mark;
	if (rule == 1) density_temp = density_rule_one(alpha1, beta1_temp, alpha2, beta2, density, degree);
	else if (rule == 2) density_temp = density_rule_two(alpha1, beta1_temp, alpha2, beta2, density, degree);
	if (density_temp > density)
	{
		last_temp = beta1_temp;
		beta1_temp *= 2;
		mark = 1;
	}
	else if (density_temp < density)
	{
		last_temp = beta1_temp;
		beta1_temp /= 2;
		mark = 0;
	}
	else return beta1_temp;
	if (rule == 1)
	{
		if (mark == 1)
		{
			while (density_rule_one(alpha1, beta1_temp, alpha2, beta2, density, degree) > density)
			{
				last_temp = beta1_temp;
				beta1_temp *= 2;
	//			cout << beta1_temp << endl;
			}
		}
		else
		{
			while (density_rule_one(alpha1, beta1_temp, alpha2, beta2, density, degree) < density)
			{
				last_temp = beta1_temp;
				beta1_temp /= 2;
	//			cout << beta1_temp << endl;
			}
		}
	}
	else
	{
		if (mark == 1)
		{
			while (density_rule_two(alpha1, beta1_temp, alpha2, beta2, density, degree) > density)
			{
				last_temp = beta1_temp;
				beta1_temp *= 2;
	//			cout << beta1_temp << endl;
			}
		}
		else
		{
			while (density_rule_two(alpha1, beta1_temp, alpha2, beta2, density, degree) < density)
			{
				last_temp = beta1_temp;
				beta1_temp /= 2;
	//			cout << beta1_temp << endl;
			}
		}
	}
	if (mark == 0)
	{
		temp_exchange = beta1_temp;
		beta1_temp = last_temp;
		last_temp = temp_exchange;
	}
	return find_out_beta1(alpha1, alpha2, beta2, last_temp, beta1_temp, density, degree, rule);
}






long double num_d_rule1(long double* trans_function, long double sum)
{
	long double temp = 0;
	int i;
	for (i = 0; i < 10000; i++)
	{
		temp += pow(2.718, -sum*trans_function[i])*0.001;
	}
	return temp;
}

long double juduizhi(long double num)
{
	if (num >= 0) return num;
	else return (-num);
}

long double ffabs(long double num)
{
	if (num < 0) return -num;
	else return num;
}