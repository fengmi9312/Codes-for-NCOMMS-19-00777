#include<iostream>
#include<fstream>
#include<string>
using namespace std;

void main()
{
	int i, j, k;
	int max;
	long double a = 0.5;
	string file;
	fstream fin;
	fstream fout;
	string name;
	long double max_v = 0, t_1 = 0, t_2 = 0, v_1 = 0, v_2 = 0, mid = 0, mid_t = 0, init = 0;
	for (j = 0; j <= 11; j++)
	{
		if (j == 0)
		{
			file = "exp_rule_one_er//";
			name = "exp_rule_one_er_output.txt";
			max = 14;
		}
		else if (j == 1)
		{
			file = "num_rule_one_er//";
			name = "num_rule_one_er_output.txt";
			max = 14;
		}
		else if (j == 2)
		{
			file = "exp_rule_one_ba//";
			name = "exp_rule_one_ba_output.txt";
			max = 16;
		}
		else if (j == 3)
		{
			file = "num_rule_one_ba//";
			name = "num_rule_one_ba_output.txt";
			max = 16;
		}
		else if (j == 4)
		{
			file = "exp_rule_one_ham//";
			name = "exp_rule_one_ham_output.txt";
			max = 16;
		}
		else if (j == 5)
		{
			file = "num_rule_one_ham//";
			name = "num_rule_one_ham_output.txt";
			max = 16;
		}
		else if (j == 6)
		{
			file = "exp_rule_two_er//";
			name = "exp_rule_two_er_output.txt";
			max = 14;
		}
		else if (j == 7)
		{
			file = "num_rule_two_er//";
			name = "num_rule_two_er_output.txt";
			max = 14;
		}
		else if (j == 8)
		{
			file = "exp_rule_two_ba//";
			name = "exp_rule_two_ba_output.txt";
			max = 16;
		}
		else if (j == 9)
		{
			file = "num_rule_two_ba//";
			name = "num_rule_two_ba_output.txt";
			max = 16;
		}
		else if (j == 10)
		{
			file = "exp_rule_two_ham//";
			name = "exp_rule_two_ham_output.txt";
			max = 16;
		}
		else
		{
			file = "num_rule_two_ham//";
			name = "num_rule_two_ham_output.txt";
			max = 16;
		}
		fout.open(name, ios::out);
		for (i = 1; i <= max; i++)
		{
			fin.open(file + to_string(i) + ".txt", ios::in);
			fin >> v_1;
			fin >> v_1;
			init = v_1;
			if (j == 7 || j == 9 || j == 11) init *= 10;
			while (!fin.eof())
			{
				fin >> v_1;
				max_v = v_1;
				if (j == 7 || j == 9 || j == 11) max_v *= 10;
			}
			fin.close();
			mid = init + (max_v - init)*a;
			fin.open(file + to_string(i) + ".txt", ios::in);
			do
			{
				t_1 = t_2;
				v_1 = v_2;
				fin >> t_2;
				fin >> v_2;
				if (j == 7 || j == 9 || j == 11) v_2 *= 10;
			} while (v_2 < mid);

			if (mid == v_1) fout << (long double)i / 4.0 << " " << t_1 << endl;
			else if (mid == v_2) fout << (long double)i / 4.0 << " " << t_2 << endl;
			else fout << (long double)i / 4.0 << " " << (((mid - v_1)*(t_2 - t_1)) / (v_2 - v_1)) + t_1 << endl;
			fin.close();
		}
		fout.close();
	}
}