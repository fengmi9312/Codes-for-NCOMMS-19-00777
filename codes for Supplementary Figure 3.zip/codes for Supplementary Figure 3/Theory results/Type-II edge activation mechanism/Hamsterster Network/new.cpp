#include<iostream>
#include<math.h>
#include<stdlib.h>
#include"network.h"
using namespace std;

int network::init_array_new_pre(int len)
{
	int i;
	all_len = len;
	for (i = 0; i < node_amount; i++)
	{
		node_pointer[i].infect_array = new long double[len];
		node_pointer[i].suscept_array = new long double[len];
	}
	return 1;
}
int network::init_array_new(long double init)
{
	int i, j;
	for (i = 0; i < node_amount; i++)
	{
		node_pointer[i].infect_array[0] = init * 1000;
		node_pointer[i].suscept_array[0] = (1 - init) * 1000;
		for (j = 1; j < all_len; j++)
		{
			node_pointer[i].infect_array[j] = 0;
			node_pointer[i].suscept_array[j] = 0;
		}
	}
	return 1;
}
int network::dynamic_rule2_new(long double* recovery_function, long double* trans_function, int area)
{
	int i, j;
	edge* edgep;
	long double i_temp, s_temp, affect_temp;
	for (i = 0; i < node_amount; i++)
	{
		node_pointer[i].affect = 0;
		for (j = 0; j < area; j++)
		{
			node_pointer[i].affect += node_pointer[i].infect_array[j] * trans_function[j];
		}
	}
	for (i = 0; i < node_amount; i++)
	{
		affect_temp = 1;
		edgep = node_pointer[i].first_edge_pointer;
		while (edgep)
		{
			affect_temp *= 1.0 - node_pointer[edgep->target_node_num].affect*0.01;
			edgep = edgep->next_edge;
		}
		affect_temp = 1.0 - affect_temp;
		i_temp = 0;
		s_temp = 0;
		for (j = area; j > 0; j--)
		{
			i_temp += node_pointer[i].infect_array[j - 1] * recovery_function[j - 1];
			s_temp += node_pointer[i].suscept_array[j - 1] * affect_temp;
			node_pointer[i].infect_array[j] = node_pointer[i].infect_array[j - 1] * (1 - recovery_function[j - 1]);
			node_pointer[i].suscept_array[j] = node_pointer[i].suscept_array[j - 1] * (1 - affect_temp);
		}
		node_pointer[i].infect_array[0] = s_temp;
		node_pointer[i].suscept_array[0] = i_temp;
	}
	return 1;
}
