#include"network.h"
using namespace std;
network::network(int num)
{
	node_pointer=new node[num];
	node_amount=num;
	edge_amount=0;
	node_infected_amount=0;
	node_susceptible_amount=num;
	network_time=0;
}
