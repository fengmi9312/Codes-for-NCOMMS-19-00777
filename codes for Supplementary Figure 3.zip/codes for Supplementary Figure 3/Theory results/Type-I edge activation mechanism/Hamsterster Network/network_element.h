
#ifndef   MY_H_FILE       //���û�ж��������  
#define   MY_H_FILE       //���������  
class node;
class edge;
class node
{
public:
	edge* first_edge_pointer;
	int degree;
	long double* infect_array;
	long double* suscept_array;
	node()
	{
		int i;
		first_edge_pointer = NULL;
		degree = 0;
	};
};
class edge
{
public:
	int node_num;
	int target_node_num;
	edge* fore_edge;
	edge* next_edge;
	edge* brother_edge;
	edge()
	{
		
		node_num = -1;
		target_node_num = -1;
		fore_edge = NULL;
		next_edge = NULL;
		brother_edge = NULL;
	};
};
#endif