#include<iostream>
#include<math.h>
#include"network.h"
using namespace std;
int network::add_edge(int node0_num,int node1_num,int direction,double weight)
{
	int find=0;
	edge* edge0=new edge;
	edge* edge1=new edge;
	if(node_pointer[node0_num].first_edge_pointer) node_pointer[node0_num].first_edge_pointer->fore_edge=edge0;
	edge0->brother_edge=edge1;
	edge0->next_edge=node_pointer[node0_num].first_edge_pointer;
	edge0->node_num=node0_num;
	edge1->node_num=node1_num;
	edge0->target_node_num=node1_num;
	node_pointer[node0_num].first_edge_pointer=edge0;
	node_pointer[node0_num].degree++;
	if(node_pointer[node1_num].first_edge_pointer) node_pointer[node1_num].first_edge_pointer->fore_edge=edge1;
	edge1->brother_edge=edge0;
	edge1->next_edge=node_pointer[node1_num].first_edge_pointer;
	edge1->target_node_num=node0_num;
	node_pointer[node1_num].first_edge_pointer=edge1;
	node_pointer[node1_num].degree++;
	edge_amount++;
//	if(edge_amount%1000==0)
//	{
//		cout<<"edge amount: "<<edge_amount<<endl;
//	}
	return 1;
}
int network::add_edge1(int node0_num,int node1_num)
{
	int find=0;
	edge* edgep;
	edge* edge0=new edge;
	edge* edge1=new edge;
	edgep=node_pointer[node0_num].first_edge_pointer;
	while(edgep)
	{
		if(edgep->node_num==node0_num&&edgep->target_node_num==node1_num)
		{
			find=1;
			break;
		}
		edgep=edgep->next_edge;
	}
	if(find==1) 
	{
		cout<<"error network?add_edge: the edge "<<node0_num<<"---"<<node1_num<<" exists, and cannot be added."<<endl;
		return 0;
	}
	if(node_pointer[node0_num].first_edge_pointer) node_pointer[node0_num].first_edge_pointer->fore_edge=edge0;
	if(node_pointer[node1_num].first_edge_pointer) node_pointer[node1_num].first_edge_pointer->fore_edge=edge1;
	edge0->brother_edge=edge1;
	edge1->brother_edge=edge0;
	edge0->next_edge=node_pointer[node0_num].first_edge_pointer;
	edge1->next_edge=node_pointer[node1_num].first_edge_pointer;
	edge0->node_num=node0_num;
	edge1->node_num=node1_num;
	edge0->target_node_num=node1_num;
	edge1->target_node_num=node0_num;
	node_pointer[node0_num].first_edge_pointer=edge0;
	node_pointer[node1_num].first_edge_pointer=edge1;
	node_pointer[node0_num].degree++;
	node_pointer[node1_num].degree++;
	edge_amount++;
	return 1;
}