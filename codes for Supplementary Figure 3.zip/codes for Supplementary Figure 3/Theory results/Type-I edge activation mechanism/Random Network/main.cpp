#include<iostream>
#include<fstream>
#include"network.h"
using namespace std;
int main()
{
	int i,j, t;
	long double temp,timed;
	long double time_limit[17]={ 4,4,4,4,4,4,4,4,5,8,10,12,17,25,50,50,50 };
	long double alpha1;
	fstream fout1("1.txt", ios::out);
	fstream fout2("2.txt", ios::out);
	fstream fout3("3.txt", ios::out);
	fstream fout4("4.txt", ios::out);
	fstream fout5("5.txt", ios::out);
	fstream fout6("6.txt", ios::out);
	fstream fout7("7.txt", ios::out);
	fstream fout8("8.txt", ios::out);
	fstream fout9("9.txt", ios::out);
	fstream fout10("10.txt", ios::out);
	fstream fout11("11.txt", ios::out);
	fstream fout12("12.txt", ios::out);
	fstream fout13("13.txt", ios::out);
	fstream fout14("14.txt", ios::out);
	fstream fout15("15.txt", ios::out);
	fstream fout16("16.txt", ios::out);
	network net(10000);
	net.creat_random_network(5);
	net.init_function_rule1_new_pre(5200);
	net.init_rule1_process_new_pre();
	for (i = 1; i <= 14; i++)
	{
		alpha1 = ((long double)i) / 4.0;
		time_limit[i] = time_limit[i];
		net.init_function_rule1_new(0.01, alpha1, 1, 2, 0.5);
		net.init_rule1_process_new(0.01);
		t = 0;
		timed = 0;
		if (i == 1) fout1 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 2) fout2 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 3) fout3 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 4) fout4 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 5) fout5 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 6) fout6 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 7) fout7 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 8) fout8 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl; 
		else if (i == 9) fout9 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 10) fout10 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 11) fout11 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 12) fout12 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl; 
		else if (i == 13) fout13 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 14) fout14 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 15) fout15 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 16) fout16 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		while(timed<=time_limit[i])
		{
			timed += 0.01;
			t++;
			net.dynamical_rule1_new(t);
			if (i == 1) fout1 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 2) fout2 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 3) fout3 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 4) fout4 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 5) fout5 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 6) fout6 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 7) fout7 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 8) fout8 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 9) fout9 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 10) fout10 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 11) fout11 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 12) fout12 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 13) fout13 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 14) fout14 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 15) fout15 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 16) fout16 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		}
	}
	return 1;
}