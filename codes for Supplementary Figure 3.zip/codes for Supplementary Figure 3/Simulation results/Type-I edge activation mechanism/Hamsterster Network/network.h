#include<iostream>
#include<fstream>
#include"network_element.h"
using namespace std;
class network
{
private:
	node* node_pointer;
	int node_amount;
	int edge_amount;
	int node_infected_amount;
	int node_susceptible_amount;
	long double network_time;
	int root_node;
	edge* root_edge;
	long double the_step;
	int array_len;
	int* i_t_temp;
	long double* p_t_average;
public:
	/*network_initial*/
	network(int num);
	/*network_output*/
	int output_node_amount();
	int output_node_infected_amount();
	long double output_network_time();
	int output_trans_rule1(long double(*infection_time)(), long double(*recovery_time)(), long double* function1, long double timestep, long double* s_i);
	int output_trans_rule2(long double(*infection_time)(), long double(*recovery_time)(), long double* function1, long double timestep, long double* s_i);
	long double output_lost_rule1(long double(*infection_time)(), long double(*recovery_time)(), long double* function1, long double* function2, long double* function3,long double degree,long double& i_density, long double timestep);
	long double output_lost_rule2(long double(*infection_time)(), long double(*recovery_time)(), long double* function1, long double* function2, long double* function3, long double degree, long double& i_density, long double timestep);
	long double output_beta1_rule1(long double alpha1, long double alpha2, long double beta2, long double density, int degree);
	long double output_all_num_d();
	/*network_operator*/
	int add_edge(int i,int j,int direction,double weight);
	int add_edge1(int i,int j);
	/*network_state*/
	int empty_all_state();
	int sis_trans_state_t(int node_num,long double (*infection_time)(),long double (*recovery_time)());
	int sis_trans_state_t1(int node_num, long double(*recovery_time)());
	/*network_activity*/
	int trans_activity_t(edge* edgep,long double (*infection_time)());
	int trans_activity_t1(edge* edgep, long double(*infection_time)());
	/*network_generation*/
	int creat_random_network(int ave_degree);
	int creat_BA_network(int initnodenum,int stepedgenum);
	int import_1100(int node_type, int amountofnode, int amountofedge);
	int empty_all_edge();
	int empty_all_net();
	int creat_configuration_model(int* degree_distribution);
	/*network_spread*/
	int init_node_state_t(int* infected,long double (*infection_time)(),long double (*recovery_time)());
	long double syn_t_sis_spread(long double(*infection_time)(), long double(*recovery_time)(), long double timestep);
	int init_node_state_t1(int* infected, long double(*infection_time)(), long double(*recovery_time)());
	long double syn_t1_sis_spread(long double(*infection_time)(), long double(*recovery_time)(), long double timestep);
	int init_num_d(long double fraction);
	int dynamical_num_d_rule1(long double *trans_infection, long double eff_recovery, long double step);
	int syn_t1_sis_spread_no_time(long double(*infection_time)(), long double(*recovery_time)(), long double timestep);
	int syn_t_sis_spread_no_time(long double(*infection_time)(), long double(*recovery_time)(), long double timestep);
	long double output_e_time(int node_num, int state);
	int update_network_time(long double timestep);
	int del_all_mark();
	int output_mark(int node_num, int state);
	/*new_spreading*/
	int init_node_tree();
	int check_node_tree(int p);
	int check_node_time_tree();
	int init_edge_tree();
	int check_edge_tree(int p);
	int check_edge_time_tree();
	int judge_node_tree(int node_num);
	int move_node_tree_left(int top_num);
	int move_node_tree_right(int top_num);
	int modify_node_tree(int node_num);
	int judge_edge_tree(edge* edgep);
	int move_edge_tree_left(edge* edgep);
	int move_edge_tree_right(edge* edgep);
	int modify_edge_tree(edge* edgep);
	int trans_activity_t_new(edge* edgep, long double(*infection_time)());
	int trans_activity_t1_new(edge* edgep, long double(*infection_time)());
	int empty_all_state_new();
	int sis_trans_state_t_new(int node_num, long double(*infection_time)(), long double(*recovery_time)());
	int sis_trans_state_t1_new(int node_num, long double(*recovery_time)());
	int init_node_state_t_new(int* infected, long double(*infection_time)(), long double(*recovery_time)());
	long double t_sis_spread_new(long double(*infection_time)(), long double(*recovery_time)());
	int init_node_state_t1_new(int* infected, long double(*infection_time)(), long double(*recovery_time)());
	long double t1_sis_spread_new(long double(*infection_time)(), long double(*recovery_time)());
	int t_sis_spread_new_mul(long double(*infection_time)(), long double(*recovery_time)(), long double timestep, int len, int times, int* infected);
	int t1_sis_spread_new_mul(long double(*infection_time)(), long double(*recovery_time)(), long double timestep, int len, int times, int* infected);
	long double* output_new_p_t(int &len,long double &timestep);
	int output()
	{
		cout << node_pointer[root_node].time << " " << root_edge->time << endl;
		return 1;
	}
};
/*txt_operator_class*/
/*
class txt_operator_out
{
private:
	ofstream txtfile;
public:
	txt_operator_out(string filename,int operate_type);
	int output_num(long double num,int decdigit,char addchar);
	int output_chars(string data);
	int output_char(char data);
	int close();
};*/
/*usual_functions*/
int uncompare(long double x,long double y);
int uncompare1(long double x,long double y);
int min_i(int x, int y);
long long int ipow(int x,int y);
int ilog(long long int x,long long int y);
long long int outputfrandnum(long long int max);
int fpossibility(long double rand,long long int acc);
int trans_double(long double num, long double step);
long double density_rule_one(long double alpha1, long double beta1, long double alpha2, long double beta2, long double density, long double degree);
long double density_rule_two(long double alpha1, long double beta1, long double alpha2, long double beta2, long double density, long double degree);
long double find_out_beta1(long double alpha1, long double alpha2, long double beta2, long double head, long double tail, long double density, long double degree, int rule);
long double find_beta1(long double alpha1, long double alpha2, long double beta2, long double density, long double degree, int rule);
long double num_d_rule1(long double* trans_function, long double sum);
long double juduizhi(long double num);
long double ffabs(long double num);
