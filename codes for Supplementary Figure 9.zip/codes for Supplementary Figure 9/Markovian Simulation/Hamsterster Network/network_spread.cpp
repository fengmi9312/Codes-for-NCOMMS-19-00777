#include<iostream>
#include<math.h>
#include"network.h"
using namespace std;
int network::init_node_state_t(int* infected,long double (*infection_time)(),long double (*recovery_time)())
{
	int i;
	edge* edgep;
	for(i=1;i<=infected[0];i++)
	{
		sis_trans_state_t(infected[i],infection_time,recovery_time);
		node_pointer[infected[i]].time=recovery_time();
		edgep=node_pointer[infected[i]].first_edge_pointer;
		while(edgep)
		{
			if(edgep->activity==1) edgep->time=infection_time();
			edgep=edgep->next_edge;
		}
	}
	return 1;
}

int network::init_node_state_t1(int* infected, long double(*infection_time)(), long double(*recovery_time)())
{
	int i;
	edge* edgep;
	for (i = 1; i <= infected[0]; i++)
	{
		sis_trans_state_t1(infected[i], recovery_time);
		edgep = node_pointer[infected[i]].first_edge_pointer;
		while (edgep)
		{
			edgep->time = infection_time();
			edgep->b_time = network_time;
			edgep = edgep->next_edge;
		}
	}
	return 1;
}

long double network::syn_t_sis_spread(long double(*infection_time)(), long double(*recovery_time)(), long double timestep)
{
	int i, m;
	int temp;
	edge* edgep;
	edge* edgepp;
	m = 1;
	while (m == 1)
	{
		m = 0;
		for (i = 0; i < node_amount; i++)
		{
			if (node_pointer[i].time>network_time&&node_pointer[i].time <= network_time + timestep)
			{
				sis_trans_state_t(i, infection_time, recovery_time);
				m = 1;
			}
			edgep = node_pointer[i].first_edge_pointer;
			while (edgep)
			{
				if (edgep->time > network_time&&edgep->time <= network_time + timestep)
				{
					temp = node_pointer[edgep->target_node_num].state;
					if (temp == 0)
					{
						sis_trans_state_t(edgep->target_node_num, infection_time, recovery_time);
					}
//					else system("pause");
					m = 1;
				}
				edgep = edgep->next_edge;
			}
		}
	}
	network_time += timestep;
	return network_time;
}

long double network::syn_t1_sis_spread(long double(*infection_time)(), long double(*recovery_time)(), long double timestep)
{
	int i, m;
	edge* edgep;
	edge* edgepp;
	m = 1;
	while (m == 1)
	{
		m = 0;
		for (i = 0; i < node_amount; i++)
		{
			if (node_pointer[i].time>network_time&&node_pointer[i].time <= network_time + timestep)
			{
				sis_trans_state_t1(i, recovery_time);
				edgepp = node_pointer[i].first_edge_pointer;
				while (edgepp)
				{
					trans_activity_t1(edgepp, infection_time);
					edgepp = edgepp->next_edge;
				}
				m = 1;
			}
			edgep = node_pointer[i].first_edge_pointer;
			while (edgep)
			{
				if (edgep->time > network_time&&edgep->time <= network_time + timestep)
				{
					if (node_pointer[edgep->target_node_num].state == 0)
					{
						sis_trans_state_t1(edgep->target_node_num, recovery_time);
						edgepp = node_pointer[edgep->target_node_num].first_edge_pointer;
						while (edgepp)
						{
							trans_activity_t1(edgepp, infection_time);
							edgepp = edgepp->next_edge;
						}
					}
					trans_activity_t1(edgep, infection_time);
					m = 1;
				}
				edgep = edgep->next_edge;
			}
		}
	}
	network_time += timestep;
	return network_time;
}


int network::syn_t_sis_spread_no_time(long double(*infection_time)(), long double(*recovery_time)(), long double timestep)
{
	int i, m;
	int temp;
	edge* edgep;
	edge* edgepp;
	m = 1;
	while (m == 1)
	{
		m = 0;
		for (i = 0; i < node_amount; i++)
		{
			if (node_pointer[i].time>network_time&&node_pointer[i].time <= network_time + timestep)
			{
				sis_trans_state_t(i, infection_time, recovery_time);
				node_pointer[i].s_birth_mark++;
				m = 1;
			}
			edgep = node_pointer[i].first_edge_pointer;
			while (edgep)
			{
				if (edgep->time > network_time&&edgep->time <= network_time + timestep)
				{
					temp = node_pointer[edgep->target_node_num].state;
					if (temp == 0)
					{
						sis_trans_state_t(edgep->target_node_num, infection_time, recovery_time);
						node_pointer[edgep->target_node_num].i_birth_mark++;
					}
					//					else system("pause");
					m = 1;
				}
				edgep = edgep->next_edge;
			}
		}
	}
	return 1;
}

int network::syn_t1_sis_spread_no_time(long double(*infection_time)(), long double(*recovery_time)(), long double timestep)
{
	int i, m;
	edge* edgep;
	edge* edgepp;
	m = 1;
	while (m == 1)
	{
		m = 0;
		for (i = 0; i < node_amount; i++)
		{
			if (node_pointer[i].time>network_time&&node_pointer[i].time <= network_time + timestep)
			{
				sis_trans_state_t1(i, recovery_time);
				node_pointer[i].s_birth_mark++;
				edgepp = node_pointer[i].first_edge_pointer;
				while (edgepp)
				{
					trans_activity_t1(edgepp, infection_time);
					edgepp = edgepp->next_edge;
				}
				m = 1;
			}
			edgep = node_pointer[i].first_edge_pointer;
			while (edgep)
			{
				if (edgep->time > network_time&&edgep->time <= network_time + timestep)
				{
					if (node_pointer[edgep->target_node_num].state == 0)
					{
						sis_trans_state_t1(edgep->target_node_num, recovery_time);
						node_pointer[edgep->target_node_num].i_birth_mark++;
						edgepp = node_pointer[edgep->target_node_num].first_edge_pointer;
						while (edgepp)
						{
							trans_activity_t1(edgepp, infection_time);
							edgepp = edgepp->next_edge;
						}
					}
					trans_activity_t1(edgep, infection_time);
					m = 1;
				}
				edgep = edgep->next_edge;
			}
		}
	}
	return 1;
}


int network::init_num_d(long double fraction)
{
	int i;
	for (i = 0; i < node_amount; i++)
	{
		node_pointer[i].num_d = fraction;
		node_pointer[i].num_sum = 0;
	}
	return 1;
}

int network::dynamical_num_d_rule1(long double *trans_infection, long double eff_recovery, long double step)
{
	int i;
	edge* edgep;
	int k = 0;
	int m = 0;
	long double num_temp;
	long double* temp = new long double[node_amount];
	while (1)
	{
		k = 0;
		for (i = 0; i < node_amount; i++)
		{
			node_pointer[i].num_sum = 0;
			edgep = node_pointer[i].first_edge_pointer;
			while (edgep)
			{
				node_pointer[i].num_sum += node_pointer[edgep->target_node_num].num_d;
				edgep = edgep->next_edge;
			}
			temp[i] = node_pointer[i].num_d - (node_pointer[i].num_d*eff_recovery - (1 - node_pointer[i].num_d) / num_d_rule1(trans_infection, node_pointer[i].num_sum))*step;
			if (juduizhi(temp[i] - node_pointer[i].num_d) > 0.00001) k = 1;
			if (temp[i] < 0 || temp[i]>1) return 0;
		}
		for (i = 0; i < node_amount; i++) node_pointer[i].num_d = temp[i];
		if (k == 0) m++;
		else m = 0;
		if (m > 20)
		{
			for (i = 0; i < node_amount; i++)
			{
				node_pointer[i].num_sum = 0;
				edgep = node_pointer[i].first_edge_pointer;
				while (edgep)
				{
					node_pointer[i].num_sum += node_pointer[edgep->target_node_num].num_d;
					edgep = edgep->next_edge;
				}
			}
			break;
		}
		num_temp = 0;
		for (i = 0; i < node_amount; i++)
		{
			num_temp += node_pointer[i].num_d / (long double)node_amount;
		}
//		cout << num_temp << endl;
	}
	delete temp;
	return 1;
}
int network::update_network_time(long double timestep)
{
	network_time += timestep;
	return 1;
}