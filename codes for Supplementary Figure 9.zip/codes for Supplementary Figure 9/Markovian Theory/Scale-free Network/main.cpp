#include"network.h"
#include<iostream>
#include<math.h>
#include<fstream>
using namespace std;

int main()
{
	int i, j, k;
	fstream fout("markovian_num.txt", ios::out);
	network net(10000);
	long double gamma, mu, time_step, init_infection;
	mu = 1;
	time_step = 0.01;
	init_infection = 0.5;
	net.creat_BA_network(15, 5);
	for (j = 1; j <= 200; j++)
	{
		gamma = ((long double)j) / 200.0;
		net.init(init_infection);
		for (k = 1; k <= 10000; k++)
		{
			net.spread_num(gamma, mu, time_step);
		}
		fout << ((long double)j) / 200.0 << " " << net.output_infection() << endl;
	}
	fout.close();
	return 1;
}