#include<iostream>
#include<math.h>
#include"network.h"
using namespace std;
int network::output_node_amount()
{
	return node_amount;
}
int network::output_node_infected_amount()
{
	return node_infected_amount;
}
long double network::output_network_time()
{
	return network_time;
}
