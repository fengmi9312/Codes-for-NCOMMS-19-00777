#include<iostream>
#include<math.h>
#include"network.h"
using namespace std;

int network::init_find_beta1(long double _alpha1, long double init_beta1, long double _alpha2, long double _beta2, long double _min_deviate, long double _lambda, long double _time_step, int _len)
{
	alpha1 = _alpha1;
	beta1 = init_beta1;
	beta1_dao = 1.0 / beta1;
	alpha2 = _alpha2;
	beta2 = _beta2;
	min_deviate = _min_deviate;
	lambda = _lambda;
	beta1_time_step = _time_step;
	len = _len;
	sur_recovery = new long double[len];
	trans_infect = new long double[len];
	find = 0;
	return 1;
}

int network::get_init_direction()
{
	refresh();
	compute_lambda();
	if (lambda_deviate > lambda + min_deviate)
	{
		left = beta1_dao/2;
		right = beta1_dao;
		beta1_dao = (left + right) / 2;
		beta1 = 1.0 / beta1_dao;
		while (!judge_left_right())
		{
			left /= 2;
			right /= 2;
			beta1_dao = (left + right) / 2;
			beta1 = 1.0 / beta1_dao;
		}
	}
	else if (lambda_deviate < lambda - min_deviate)
	{
		left = beta1_dao;
		right = beta1_dao*2;
		beta1_dao = (left + right) / 2;
		beta1 = 1.0 / beta1_dao;
		while (!judge_left_right())
		{
			left *= 2;
			right *= 2;
			beta1_dao = (left + right) / 2;
			beta1 = 1.0 / beta1_dao;
		}
	}
	else find = 1;
	return 1;
}

int network::judge_left_right()
{
	long double temp_left, temp_right;
	beta1_dao = left;
	beta1 = 1.0 / beta1_dao;
	refresh();
	compute_lambda();
	temp_left = lambda_deviate;
	beta1_dao = right;
	beta1 = 1.0 / beta1_dao;
	refresh();
	compute_lambda();
	temp_right = lambda_deviate;
	beta1_dao = (left+right)/2;
	beta1 = 1.0 / beta1_dao;
	refresh();
	compute_lambda();
	if (temp_left<=lambda&&temp_right>=lambda) return 1;
	else return 0;
}

int network::refresh()
{
	int i, j;
	for (i = 0; i < len; i++)
	{
		sur_recovery[i] = pow(2.718, -pow(((long double)i)*beta1_time_step / beta2, alpha2));
	}
	for (j = 0; j < len; j++)
	{
		trans_infect[j] = pow(2.718, -pow(((long double)j)*beta1_time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(j + 1))*beta1_time_step / beta1, alpha1));
		for (i = 0; i < j; i++)
		{
			trans_infect[j] += trans_infect[i] * (pow(2.718, -pow(((long double)(j - i - 1))*beta1_time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(j - i))*beta1_time_step / beta1, alpha1)));
		}
	}
	return 1;
}

int network::compute_lambda()
{
	int i;
	lambda_deviate = 0;
	for (i = 0; i < len; i++)
	{
		lambda_deviate += sur_recovery[i] * trans_infect[i];
	}
	return 1;
}

int network::modify_beta1()
{
	refresh();
	compute_lambda();
//	cout << beta1 << " " << lambda_deviate << endl;
	if (lambda_deviate > lambda + min_deviate)
	{
		right = beta1_dao;
		beta1_dao = (left + right) / 2;
		beta1 = 1.0 / beta1_dao;
	}
	else if (lambda_deviate < lambda - min_deviate)
	{
		left = beta1_dao;
		beta1_dao = (left + right) / 2;
		beta1 = 1.0 / beta1_dao;
	}
	else find = 1;
	return 1;
}

int network::close_find()
{
	alpha1 = 0;
	beta1 = 0;
	beta1_dao = 0;
	alpha2 = 0;
	beta2 = 0;
	min_deviate = 0;
	lambda = 0;
	beta1_time_step = 0;
	len = 0;
	find = 0;
	delete sur_recovery;
	delete trans_infect;
	return 1;
}

long double network::get_right_beta1(long double &_lambda_deviate)
{
	get_init_direction();
	if (find == 1)
	{
		_lambda_deviate = lambda_deviate;
		return beta1;
	}
	do
	{
		modify_beta1();
	} while (find == 0);
	_lambda_deviate = lambda_deviate;
	return beta1;
}