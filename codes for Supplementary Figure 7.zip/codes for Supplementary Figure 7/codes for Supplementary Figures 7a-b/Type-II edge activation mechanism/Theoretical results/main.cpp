#include"network.h"
#include<iostream>
#include<math.h>
#include<fstream>
using namespace std;

long double infect_function[605];
long double recover_function[605];
long double trans_infect_function[605];
int init_in_su(long double alpha1, long double beta1, long double alpha2, long double beta2, long double time_step)
{
	int i, j;
	for (i = 0; i < 605; i++)
	{
		if (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) == 0) infect_function[i] = 1;
		else infect_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta1, alpha1))) / pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1));
		if (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) == 0) recover_function[i] = 1;
		else recover_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta2, alpha2))) / pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2));
	}
	for (j = 0; j < 605; j++)
	{
		trans_infect_function[j] = pow(2.718, -pow(((long double)j)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(j + 1))*time_step / beta1, alpha1));
		for (i = 0; i < j; i++)
		{
			trans_infect_function[j] += trans_infect_function[i] * (pow(2.718, -pow(((long double)(j - i - 1))*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(j - i))*time_step / beta1, alpha1)));
		}
	}
	return 1;
}
int main()
{
	int i, t;
	long double timed,temp;
	long double alpha1;
	fstream fout05("05.txt", ios::out);
	fstream fout10("10.txt", ios::out);
	fstream fout20("20.txt", ios::out);
	fstream fout40("40.txt", ios::out); 
	network net(10000);
	scale_free_p* degree_p;
	degree_p = new scale_free_p(100, 5, 2.3, 100000);
	net.creat_configuration_model(degree_p->output_degree_array(net.output_node_amount()));
	net.init_array_new_pre(607);
	for (i = 1; i <= 4; i++)
	{
		if (i == 1) alpha1 = 0.5;
		else if (i == 2) alpha1 = 1.0;
		else if (i == 3) alpha1 = 2.0;
		else alpha1 = 4.0;
		init_in_su(alpha1, 1, 2, 0.5, 0.01);
		net.init_array_new(0.01);
		timed = 0;
		t = 0;
		if (i == 1) fout05 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 2) fout10 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 3) fout20 << timed << " " << net.output_all_array_i(t) << endl;
		else fout40 << timed << " " << net.output_all_array_i(t) << endl;
		while (timed < 6.02)
		{
			timed += 0.01;
			t++;
			net.dynamic_rule2_new(recover_function, trans_infect_function, t);
			if (i == 1) fout05 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 2) fout10 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 3) fout20 << timed << " " << net.output_all_array_i(t) << endl;
			else fout40 << timed << " " << net.output_all_array_i(t) << endl;
		}
	}
	fout05.close();
	fout10.close();
	fout20.close();
	fout40.close();
	return 1;
}
