#pragma once 

class node;
class edge;
class node
{
public:
	edge* first_edge_pointer;
	int left_child;
	int right_child;
	int father;
	int degree;
	int state;
	long double time;
	long double b_time;
	long double num_d;
	long double num_sum;
	int i_birth_mark;
	int s_birth_mark;
	node()
	{
		int i;
		left_child = -1;
		right_child = -1;
		father = -1;
		first_edge_pointer=NULL;
		degree=0;
		state=0;
		time=-1;
		b_time=0;
		num_d;
		num_sum;
		i_birth_mark = 0;
		s_birth_mark = 1;
	};
};
class edge
{
public:
	int node_num;
	int target_node_num;
	edge* fore_edge;
	edge* next_edge;
	edge* brother_edge;
	edge* left_child;
	edge* right_child;
	edge* father;
	int activity;
	int direction;
	double weight;
	long double time;
	long double b_time;
	edge()
	{
		node_num=-1;
		target_node_num=-1;
		fore_edge=NULL;
		next_edge=NULL;
		brother_edge=NULL;
		left_child = NULL;
		right_child = NULL;
		father = NULL;
		activity = 0;
		direction=0;
		weight=1;
		time=-1;
	};
};