#include<math.h>
#include<fstream>
#include<stdlib.h>
#include"network.h"
using namespace std;
int network::creat_random_network(int ave_degree)
{
	int i,j;
	for(i=0;i<node_amount;i++)
		for(j=0;j<ave_degree;j++)
			add_edge(i,outputfrandnum(node_amount*10)/10,0,1);
	return 1;
}
int network::creat_BA_network(int initnodenum,int stepedgenum)
{
    int i,j,k,t,e,udgr;
	int* p;
	long long int num;
	if(initnodenum<stepedgenum)
	{
//		cout<<"error undirected?creatsfnet:initnodenum<stepedgenum!"<<endl;
		return 0;
	}
	if(initnodenum==1);
	else if(initnodenum==2) add_edge1(0,1);
	else if(initnodenum<=0) 
	{
//		cout<<"error undirected?creatsfnet:initnodenum<=0!"<<endl;
		return 0;
	}
	else
	{
        for(i=0;i<initnodenum;i++)
        {
	    	j=i+1;
	    	if(j==initnodenum) j=0;
            add_edge1(i,j);
        }
	}
	p=(int*)malloc(stepedgenum*sizeof(int));
	for(i=initnodenum;i<node_amount;i++)
	{
        for(j=0;j<stepedgenum;j++)
        {
	        do{
	    	     num=outputfrandnum(edge_amount*2);
	    	     for(k=0;k<i;k++)
	    	     {
					 udgr=node_pointer[k].degree;
	    	 		 num=num-udgr;
				 	 if(num<0) break;
	    	     }
				 e=0;
				 for(t=0;t<j;t++)
				 {
					 if(p[t]==k)
					 {
						 e=1;
						 break;
					 }
				 }
	         }while(e==1);
			 p[j]=k;
         }
		for(j=0;j<stepedgenum;j++) add_edge1(i,p[j]);
	}
	free(p);
    return 1;
}


int network::empty_all_edge()
{
	int i;
	edge* edgep;
	edge* temp;
	for (i = 0; i<node_amount; i++)
	{
		node_pointer[i].degree = 0;
		temp = node_pointer[i].first_edge_pointer;
		while (temp)
		{
			edgep = temp;
			temp = edgep->next_edge;
			delete edgep;
		}
		node_pointer[i].first_edge_pointer = NULL;
	}
	edge_amount = 0;
	return 1;
}
int network::empty_all_net()
{
	empty_all_edge();
	delete node_pointer;
	node_amount = 0;
	return 1;
}
int network::import_1100(int node_type, int amountofnode, int amountofedge)
{
	ifstream txtfile("real_network.txt", ios::in);
	int i, j;
	int node0, node1;
	empty_all_net();
	edge_amount = 0;
	i = 0;
	node_amount = amountofnode;
	node_pointer = new node[node_amount]();
	for (j = 0; j<amountofedge; j++)
	{
		txtfile >> node0;
		txtfile >> node1;
		if (node_type == 1)
		{
			node0--;
			node1--;
		}
		add_edge(node0, node1, 0, 1);
	}
	txtfile.close();
	return 1;
}


int network::creat_configuration_model(int* degree_distribution)
{
	int i, j, degree_sum = 0, headtemp, node0, node1;
	int* temp;
	edge* edgep;
	edge* edgep0;
	edge* edgep1;
	for (i = 1; i <= degree_distribution[0]; i++)
	{
		degree_sum += degree_distribution[i];
	}
	if (degree_sum % 2 != 0)
	{
		//cout << "error network?creat_configuration_model::the sum of degrees must be even!" << endl;
		return 0;
	}
	temp = (int*)malloc((degree_distribution[0] + 1) * sizeof(int));
	for (i = 0; i <= degree_distribution[0]; i++)
	{
		temp[i] = degree_distribution[i];
	}
	empty_all_net();
	node_pointer = new node[degree_distribution[0]]();
	node_amount = degree_distribution[0];
	for (i = 1; i <= degree_distribution[0]; i++)
	{
		node_pointer[i - 1].degree = degree_distribution[i];
		for (j = 0; j<node_pointer[i - 1].degree; j++)
		{
			edgep = new edge();
			edgep->node_num = i - 1;
			edgep->next_edge = node_pointer[i - 1].first_edge_pointer;
			edgep->fore_edge = NULL;
			node_pointer[i - 1].first_edge_pointer = edgep;
			if (edgep->next_edge) edgep->next_edge->fore_edge = edgep;
		}
	}
	while (degree_sum)
	{
		headtemp = outputfrandnum(degree_sum);
		degree_sum--;
		i = 0;
		while (headtemp >= 0)
		{
			i++;
			headtemp = headtemp - degree_distribution[i];
		}
		degree_distribution[i]--;
		node0 = i - 1;
		headtemp = outputfrandnum(degree_sum);
		degree_sum--;
		i = 0;
		while (headtemp >= 0)
		{
			i++;
			headtemp = headtemp - degree_distribution[i];
		}
		degree_distribution[i]--;
		node1 = i - 1;
		edgep = node_pointer[node0].first_edge_pointer;
		while (edgep)
		{
			if (edgep->target_node_num == -1)
			{
				edgep0 = edgep;
				edgep->target_node_num = -2;
				break;
			}
			edgep = edgep->next_edge;
		}
		edgep = node_pointer[node1].first_edge_pointer;
		while (edgep)
		{
			if (edgep->target_node_num == -1)
			{
				edgep1 = edgep;
				edgep->target_node_num = -2;
				break;
			}
			edgep = edgep->next_edge;
		}
		edgep0->brother_edge = edgep1;
		edgep1->brother_edge = edgep0;
		edgep0->target_node_num = edgep1->node_num;
		edgep1->target_node_num = edgep0->node_num;
		edge_amount++;
	}
	return 1;
}