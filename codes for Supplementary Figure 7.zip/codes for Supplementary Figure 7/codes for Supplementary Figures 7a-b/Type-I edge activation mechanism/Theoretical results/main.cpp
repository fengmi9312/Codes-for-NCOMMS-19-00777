#include<iostream>
#include<fstream>
#include"network.h"
using namespace std;
int main()
{
	int i,j, t;
	long double temp,timed;
	long double alpha1;
	fstream fout05("05.txt", ios::out);
	fstream fout10("10.txt", ios::out);
	fstream fout20("20.txt", ios::out);
	fstream fout40("40.txt", ios::out);
	network net(10000);
	scale_free_p* degree_p;
	degree_p = new scale_free_p(100, 5, 2.3, 100000);
	net.creat_configuration_model(degree_p->output_degree_array(net.output_node_amount()));
	net.init_function_rule1_new_pre(605);
	net.init_rule1_process_new_pre();
	for (i = 1; i <= 4; i++)
	{
		if (i == 1) alpha1 = 0.5;
		else if (i == 2) alpha1 = 1.0;
		else if (i == 3) alpha1 = 2.0;
		else alpha1 = 4.0;
		net.init_function_rule1_new(0.01, alpha1, 1, 2, 0.5);
		net.init_rule1_process_new(0.01);
		t = 0;
		timed = 0;
		if (i == 1) fout05 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 2) fout10 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 3) fout20 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else fout40 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		while(timed<=6.01)
		{
			timed += 0.01;
			t++;
			net.dynamical_rule1_new(t);
			if (i == 1) fout05 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 2) fout10 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 3) fout20 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else fout40 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		}
	}
	fout05.close();
	fout10.close();
	fout20.close();
	fout40.close();
	return 1;
}