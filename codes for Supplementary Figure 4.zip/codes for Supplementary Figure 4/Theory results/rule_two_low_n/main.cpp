#include"network.h"
#include<iostream>
#include<math.h>
#include<fstream>
using namespace std;

long double infect_function[4301];
long double recover_function[4301];
long double trans_infect_function[4301];
int init_in_su(long double alpha1, long double beta1, long double alpha2, long double beta2, long double time_step)
{
	int i, j;
	for (i = 0; i < 4301; i++)
	{
		if (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) == 0) infect_function[i] = 1;
		else infect_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta1, alpha1))) / pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1));
		if (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) == 0) recover_function[i] = 1;
		else recover_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta2, alpha2))) / pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2));
	}
	for (j = 0; j < 4300; j++)
	{
		trans_infect_function[j] = pow(2.718, -pow(((long double)j)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(j + 1))*time_step / beta1, alpha1));
		for (i = 0; i < j; i++)
		{
			trans_infect_function[j] += trans_infect_function[i] * (pow(2.718, -pow(((long double)(j - i - 1))*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(j - i))*time_step / beta1, alpha1)));
		}
	}
	return 1;
}
int main()
{
	int i, t;
	long double timed,temp;
	long double alpha1;
	fstream fout2("2.txt", ios::out);
	fstream fout3("3.txt", ios::out);
	fstream fout4("4.txt", ios::out); 
	fstream fout5("5.txt", ios::out);
	fstream fout6("6.txt", ios::out);
	fstream fout7("7.txt", ios::out);
	fstream fout8("8.txt", ios::out);
	fstream fout9("9.txt", ios::out);
	fstream fout10("10.txt", ios::out);
	fstream fout11("11.txt", ios::out);
	fstream fout12("12.txt", ios::out);
	network net(10000);
	scale_free_p* degree_p;
	for (i = 2; i <= 12; i++)
	{
		degree_p = new scale_free_p(100, i, 2.3, 100000);
		alpha1 = 2.0;
		init_in_su(alpha1, 1, 2, 0.5, 0.01);
		net.creat_configuration_model(degree_p->output_degree_array(net.output_node_amount()));
		net.init_array_new_pre(700);
		net.init_array_new(0.01);
		timed = 0;
		t = 0;
		if (i == 2) fout2 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 3) fout3 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 4) fout4 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 5) fout5 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 6) fout6 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 7) fout7 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 8) fout8 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 9) fout9 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 10) fout10 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 11) fout11 << timed << " " << net.output_all_array_i(t) << endl;
		else if (i == 12) fout12 << timed << " " << net.output_all_array_i(t) << endl;
		while (timed <= 6)
		{
			timed += 0.01;
			t++;
			net.dynamic_rule2_new(recover_function, trans_infect_function, t);
			if (i == 2) fout2 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 3) fout3 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 4) fout4 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 5) fout5 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 6) fout6 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 7) fout7 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 8) fout8 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 9) fout9 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 10) fout10 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 11) fout11 << timed << " " << net.output_all_array_i(t) << endl;
			else if (i == 12) fout12 << timed << " " << net.output_all_array_i(t) << endl;
		}
		delete degree_p;
	}
	return 1;
}
