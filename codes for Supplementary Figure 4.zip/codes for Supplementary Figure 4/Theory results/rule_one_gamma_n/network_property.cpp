#include<iostream>
#include<fstream>
#include<math.h>
#include<string>
#include"network.h"
using namespace std;

double network::n_order_moment(int n)
{
	int i;
	long double degree_sum=0;
	int node_degree;
	if(node_amount<=0)
	{
		cout<<"error nordermoment:no node!"<<endl;
		return 0;
	}
	for(i=0;i<node_amount;i++)
	{
		node_degree=node_pointer[i].degree;
		degree_sum=degree_sum+pow((double)node_degree,n);
	}
	return degree_sum/((double)node_amount);
}