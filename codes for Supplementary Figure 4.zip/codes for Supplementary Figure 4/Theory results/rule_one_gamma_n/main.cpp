#include<iostream>
#include<fstream>
#include"network.h"
using namespace std;
int main()
{
	int i,j, t;
	long double temp,timed;
	long double alpha1;
	fstream fout0("20.txt", ios::out);
	fstream fout1("21.txt", ios::out);
	fstream fout2("22.txt", ios::out);
	fstream fout3("23.txt", ios::out);
	fstream fout4("24.txt", ios::out);
	fstream fout5("25.txt", ios::out);
	fstream fout6("26.txt", ios::out);
	fstream fout7("27.txt", ios::out);
	fstream fout8("28.txt", ios::out);
	fstream fout9("29.txt", ios::out);
	fstream fout10("30.txt", ios::out);
	network net(10000);
	scale_free_p* degree_p;
	for (i = 0; i <= 10; i++)
	{
		alpha1 = 2.0;
		degree_p = new scale_free_p(100, 5, 2.0 + ((long double)i) / 10.0, 100000);
		net.creat_configuration_model(degree_p->output_degree_array(net.output_node_amount()));
		net.init_function_rule1_new_pre(700);
		net.init_rule1_process_new_pre();
		net.init_function_rule1_new(0.01, alpha1, 1, 2, 0.5);
		net.init_rule1_process_new(0.01);
		t = 0;
		timed = 0;
		if (i == 0) fout0 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 1) fout1 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 2) fout2 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 3) fout3 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 4) fout4 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 5) fout5 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 6) fout6 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 7) fout7 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 8) fout8 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 9) fout9 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		else if (i == 10) fout10 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		while(timed<=6)
		{
			timed += 0.01;
			t++;
			net.dynamical_rule1_new(t);


			if (i == 0) fout0 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 1) fout1 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 2) fout2 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 3) fout3 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 4) fout4 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 5) fout5 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 6) fout6 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 7) fout7 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 8) fout8 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 9) fout9 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
			else if (i == 10) fout10 << timed << " " << net.output_all_node_array_infect_new_new(t + 1) << endl;
		}
		delete degree_p;
	}
	return 1;
}