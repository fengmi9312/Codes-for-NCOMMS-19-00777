#include<iostream>
#include<math.h>
#include"network.h"
using namespace std;

int network::init_function_rule1_new_pre(int len)
{
	temp_matrix_length = len;
	infect_function = new long double[len];
	recover_function = new long double[len];
	return 1;
}
int network::init_function_rule1_new(long double time_step, long double alpha1, long double beta1, long double alpha2, long double beta2)
{
	timestep = time_step;
	int i, j;
	for (i = 0; i < temp_matrix_length; i++)
	{
		if (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) == 0) infect_function[i] = 1;
		else infect_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta1, alpha1))) / pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1));
		if (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) == 0) recover_function[i] = 1;
		else recover_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta2, alpha2))) / pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2));
	}
	return 1;
}
int network::init_rule1_process_new_pre()
{
	int i, j;
	for (i = 0; i < node_amount; i++)
	{
		node_pointer[i].infect_array = new long double[temp_matrix_length];
		node_pointer[i].suscept_array = new long double[temp_matrix_length];
	}
	return 1;
}
int network::init_rule1_process_new(long double init)
{
	int i, j;
	for (i = 0; i < node_amount; i++)
	{
		node_pointer[i].infect_array[0] = init / timestep;
		node_pointer[i].suscept_array[0] = (1 - init) / timestep;
		for (j = 1; j < temp_matrix_length; j++)
		{
			node_pointer[i].infect_array[j] = 0;
			node_pointer[i].suscept_array[j] = 0;
		}
	}
	return 1;
}
int network::dynamical_rule1_new(int temp_len)
{
	int i, j;
	edge* edgep;
	long double affect_temp;
	long double* lost_i = new long double[node_amount];
	long double* lost_s = new long double[node_amount];
	long double* tempxp = new long double[node_amount];
	long double* tempyp = new long double[node_amount];
	long double* affect_p = new long double[node_amount];

	for (i = 0; i < node_amount; i++)
	{
		lost_i[i] = 0;
		lost_s[i] = 0;
		tempxp[i] = 0;
		tempyp[i] = 0;
		for (j = 0; j < temp_len; j++) 
			tempyp[i] += node_pointer[i].infect_array[j];
	}
	for (i = 0; i < temp_len; i++)
	{
		for (j = 0; j < node_amount; j++) affect_p[j] = 1;
		for (j = 0; j < node_amount; j++)
		{
			tempxp[j] += node_pointer[j].infect_array[i] * infect_function[i];
			tempyp[j] -= node_pointer[j].infect_array[i];
			affect_temp = tempxp[j] + infect_function[i] * tempyp[j];
			edgep = node_pointer[j].first_edge_pointer;
			while (edgep)
			{
				affect_p[edgep->target_node_num] *=1.0- affect_temp*timestep;
				edgep = edgep->next_edge;
			}
		}
		for (j = 0; j < node_amount; j++) affect_p[j] = 1 - affect_p[j];
		for (j = 0; j < node_amount; j++)
		{
			lost_i[j] += node_pointer[j].infect_array[i] * recover_function[i];
			lost_s[j] += node_pointer[j].suscept_array[i] * affect_p[j];
			node_pointer[j].infect_array[i] *= 1 - recover_function[i];
			node_pointer[j].suscept_array[i] *= 1 - affect_p[j];
		}
	}
	for (i = 0; i < node_amount; i++)
	{
		for (j = temp_len; j > 0; j--)
		{
			node_pointer[i].infect_array[j] = node_pointer[i].infect_array[j - 1];
			node_pointer[i].suscept_array[j] = node_pointer[i].suscept_array[j - 1];
		}
		node_pointer[i].infect_array[0] = lost_s[i];
		node_pointer[i].suscept_array[0] = lost_i[i];
	}
	delete lost_s;
	delete lost_i;
	delete tempxp;
	delete tempyp;
	delete affect_p;
	return 1;
}
long double network::output_node_array_infect_new_new(int num,int temp_len)
{
	int i;
	long double temp = 0;
	for (i = 0; i < temp_len; i++)
	{
		temp += node_pointer[num].infect_array[i] * timestep;
	}
	return temp;
}

long double network::output_all_node_array_infect_new_new(int temp_len)
{
	int i;
	long double temp = 0;
	for (i = 0; i < node_amount; i++) temp += output_node_array_infect_new_new(i,temp_len);
	return temp / node_amount;
}