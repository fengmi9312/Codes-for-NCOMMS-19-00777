#include<iostream>
#include<math.h>
#include"network.h"
using namespace std;
int network::output_node_amount()
{
	return node_amount;
}
int network::output_node_infected_amount()
{
	return node_infected_amount;
}
long double network::output_network_time()
{
	return network_time;
}

long double network::output_all_array_i(int area)
{
	int i, j,amount_temp;
	long double temp;
	temp = 0;
	amount_temp = node_amount;
	for (i = 0; i < node_amount; i++)
	{
		for (j = 0; j <= area; j++)
		{
			temp += node_pointer[i].infect_array[j] * 0.001;
		}
	}
	temp /= ((long double)amount_temp);
	return temp;
}

long double network::output_all_array_s(int area)
{
	int i, j, amount_temp;
	long double temp;
	temp = 0;
	amount_temp = node_amount;
	for (i = 0; i < node_amount; i++)
	{
		for (j = 0; j <= area; j++)
		{
			temp += node_pointer[i].suscept_array[j] * 0.001;
		}
	}
	temp /= ((long double)amount_temp);
	return temp;
}