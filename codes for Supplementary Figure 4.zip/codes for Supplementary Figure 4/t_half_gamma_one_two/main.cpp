#include<iostream>
#include<fstream>
#include<string>
using namespace std;

void main()
{
	int i, j, k;
	long double a=0.5;
	string file;
	fstream fin;
	fstream fout;
	long double v_1 = 0, v_2 = 0, t_1 = 0, t_2 = 0, mid_t = 0, max_v = 0, mid_v = 0, init = 0;
	for (j = 1; j <= 4; j++)
	{
		if (j == 1)
		{
			fout.open("exp_gamma_output_rule_one.txt", ios::out);
			file = "exp_rule_one\\";
		}
		else if (j == 2)
		{
			fout.open("num_gamma_output_rule_one.txt", ios::out);
			file = "num_rule_one\\";
		}
		else if (j == 3)
		{
			fout.open("exp_gamma_output_rule_two.txt", ios::out);
			file = "exp_rule_two\\";
		}
		else
		{
			fout.open("num_gamma_output_rule_two.txt", ios::out);
			file = "num_rule_two\\";
		}
		for (i = 20; i <= 30; i++)
		{
			fin.open(file + to_string(i) + ".txt", ios::in);
			fin >> v_1;
			fin >> v_1;
			init = v_1;
			if (j == 4) init *= 10;
			while (!fin.eof())
			{
				fin >> v_1;
				max_v = v_1;
				if (j == 4) max_v *= 10;
			}
			fin.close();
			mid_v = init + (max_v - init)*a;
			fin.open(file + to_string(i) + ".txt", ios::in);
			do
			{
				t_1 = t_2;
				v_1 = v_2;
				fin >> t_2;
				fin >> v_2;
				if (j == 4) v_2 *= 10;
			} while (v_2 < mid_v);
			if (mid_v == v_1) fout << (long double)i / 10.0 << " " << t_1 << endl;
			else if (mid_v == v_2) fout << (long double)i / 10.0 << " " << t_2 << endl;
			else fout << (long double)i / 10.0 << " " << (((mid_v - v_1)*(t_2 - t_1)) / (v_2 - v_1)) + t_1 << endl;
			fin.close();
		}
		fout.close();
	}
}