#include<iostream>
#include<fstream>
#include<string>
#include<math.h>
#include<fstream>
#include"network.h"
using namespace std;



long double a1 = 0, b1 = 1, a2 = 2, b2 = 0.5;
long double infection()
{
	return b1 * pow((log(100000.0) - log((long double)outputfrandnum(100000))) / log(2.718), 1 / a1);
}

long double recovery()
{
	return b2 * pow((log(100000.0) - log((long double)outputfrandnum(100000))) / log(2.718), 1 / a2);
}
int main()
{
	
	fstream fout2("2.txt", ios::out);
	fstream fout3("3.txt", ios::out);
	fstream fout4("4.txt", ios::out);
	fstream fout5("5.txt", ios::out);
	fstream fout6("6.txt", ios::out);
	fstream fout7("7.txt", ios::out);
	fstream fout8("8.txt", ios::out);
	fstream fout9("9.txt", ios::out);
	fstream fout10("10.txt", ios::out);
	fstream fout11("11.txt", ios::out);
	fstream fout12("12.txt", ios::out);
	int i,j,ppp;
	int len;
	long double timestep;
	long double* eout;
	network net(10000);
	scale_free_p* degree_p;
	int i_init[101];
	int r_init[1];
	r_init[0] = 0;
	i_init[0] = 100;
	int temp_, y,k;
	for (i = 1; i <= i_init[0]; i++)
	{
		do {
			y = 0;
			temp_ = outputfrandnum(net.output_node_amount());
			for (j = 1; j < i; j++)
			{
				if (i_init[j] == temp_) y = 1;
			}
		} while (y == 1);
		i_init[i] = temp_;
	}
	for (ppp = 2; ppp <= 12; ppp++)
	{
		a1 = 2.0;
		degree_p = new scale_free_p(100, ppp, 2.3, 100000);
		net.creat_configuration_model(degree_p->output_degree_array(net.output_node_amount()));
		net.t1_sis_spread_new_mul(infection, recovery, 0.01, 600, 100, i_init);
		eout = net.output_new_p_t(len, timestep);
		for (i = 0; i <= len; i++)
		{
			if (ppp == 2) fout2 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 3) fout3 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 4) fout4 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 5) fout5 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 6) fout6 << ((long double)i)*timestep << " " << eout[i] << endl; 
			else if (ppp == 7) fout7 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 8) fout8 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 9) fout9 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 10) fout10 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 11) fout11 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 12) fout12 << ((long double)i)*timestep << " " << eout[i] << endl;
		}
		delete degree_p;
	}
	return 1;
}