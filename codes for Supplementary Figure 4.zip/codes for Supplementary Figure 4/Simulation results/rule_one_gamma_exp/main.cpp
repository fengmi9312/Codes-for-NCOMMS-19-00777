#include<iostream>
#include<fstream>
#include<string>
#include<math.h>
#include<fstream>
#include"network.h"
using namespace std;



long double a1 = 0, b1 = 1, a2 = 2, b2 = 0.5;
long double infection()
{
	return b1 * pow((log(100000.0) - log((long double)outputfrandnum(100000))) / log(2.718), 1 / a1);
}

long double recovery()
{
	return b2 * pow((log(100000.0) - log((long double)outputfrandnum(100000))) / log(2.718), 1 / a2);
}
int main()
{
	fstream fout0("20.txt", ios::out);
	fstream fout1("21.txt", ios::out);
	fstream fout2("22.txt", ios::out);
	fstream fout3("23.txt", ios::out);
	fstream fout4("24.txt", ios::out);
	fstream fout5("25.txt", ios::out);
	fstream fout6("26.txt", ios::out); 
	fstream fout7("27.txt", ios::out);
	fstream fout8("28.txt", ios::out);
	fstream fout9("29.txt", ios::out);
	fstream fout10("30.txt", ios::out);
	int i,j,ppp;
	int len;
	long double timestep;
	long double* eout;
	scale_free_p* degree_p;
	network net(10000);
	int i_init[101];
	int r_init[1];
	r_init[0] = 0;
	i_init[0] = 100;
	int temp_, y,k;
	for (i = 1; i <= i_init[0]; i++)
	{
		do {
			y = 0;
			temp_ = outputfrandnum(net.output_node_amount());
			for (j = 1; j < i; j++)
			{
				if (i_init[j] == temp_) y = 1;
			}
		} while (y == 1);
		i_init[i] = temp_;
	}
	for (ppp = 0; ppp <= 10; ppp++)
	{
		a1 = 2.0;
		degree_p = new scale_free_p(100, 5, 2.0 + ((long double)ppp) / 10.0, 100000);
		net.creat_configuration_model(degree_p->output_degree_array(net.output_node_amount()));
		net.t_sis_spread_new_mul(infection, recovery, 0.01, 600, 100, i_init);
		eout = net.output_new_p_t(len, timestep);
		for (i = 0; i <= len; i++)
		{
			if (ppp == 0) fout0 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 1) fout1 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 2) fout2 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 3) fout3 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 4) fout4 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 5) fout5 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 6) fout6 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 7) fout7 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 8) fout8 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 9) fout9 << ((long double)i)*timestep << " " << eout[i] << endl;
			else if (ppp == 10) fout10 << ((long double)i)*timestep << " " << eout[i] << endl;
		}
		delete degree_p;
	}
	return 1;
}