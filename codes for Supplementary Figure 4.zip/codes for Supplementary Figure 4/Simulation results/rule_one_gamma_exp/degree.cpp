#include"network.h"
#include<math.h>
using namespace std;


scale_free_p::scale_free_p(int _max, int _min, long double g, int acc)
{
	int i;
	p_array = new long long int[_max - _min + 1];
	max_degree = _max;
	min_degree = _min;
	gamma = g;
	pre = acc;
	_sum = 0;
	for (i = min_degree; i <= max_degree; i++)
	{
		p_array[i - min_degree] = ((long long int)(pow(((long double)i), -gamma)*((long double)pre)));
		_sum += p_array[i - min_degree];
	}
}

scale_free_p::~scale_free_p()
{
	delete p_array;
}

int scale_free_p::output_degree()
{
	long long int temp;
	int i, temp_i;
	temp = outputfrandnum(_sum);
	for (i = min_degree; i <= max_degree; i++)
	{
		temp -= p_array[i - min_degree];
		if (temp<0)
		{
			temp_i = i;
			break;
		}
	}
	return temp_i;
}
int* scale_free_p::output_degree_array(int node_amount)
{
	int* degree_array;
	int i;
	int degree_sum;
	degree_array = new int[node_amount + 1];
	degree_array[0] = node_amount;
	degree_sum = 0;
	for (i = 1; i <= node_amount; i++)
	{
		degree_array[i] = output_degree();
		degree_sum += degree_array[i];
	}
	if (degree_sum % 2 == 1) degree_array[outputfrandnum(node_amount) + 1]++;
	return degree_array;
}