#include<iostream>
#include<fstream>
#include"network.h"
using namespace std;

int main()
{
	long double time_limit = 6;
	long double time;
	long double i_temp_kk;
	long double alpha1=1;
	fstream fout1("numerical_10.txt", ios::out);
	network net(10000);
	net.creat_random_network(5);
	net.init_function_rule1(6100, 0.001, alpha1, 1, 2, 0.5);
	net.init_rule1_process(0.01);
	time = 0;
	i_temp_kk = net.output_all_node_array_infect_new();
	fout1 << time << " " << i_temp_kk << endl;
	while (time <= time_limit)
	{
		net.dynamical_rule1();
		time += 0.001;
		i_temp_kk = net.output_all_node_array_infect_new();
		fout1 << time << " " << i_temp_kk << endl;
	}
	return 1;
}