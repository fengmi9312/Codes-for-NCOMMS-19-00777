#include<iostream>
#include<fstream>
#include"network_element.h"
using namespace std;
class network
{
private:
	node* node_pointer;
	int node_amount;
	int edge_amount;
	int node_infected_amount;
	int node_susceptible_amount;
	long double network_time;
public:
	/*network_initial*/
	network(int num);
	/*network_output*/
	int output_node_amount();
	int output_node_infected_amount();
	long double output_network_time();
	/*network_operator*/
	int add_edge(int i,int j,int direction,double weight);
	int add_edge1(int i,int j);
	/*network_state*/
	int empty_all_state();
	int sis_trans_state_t(int node_num,long double (*infection_time)(),long double (*recovery_time)());
	int sis_trans_state_t1(int node_num, long double(*recovery_time)());
	/*network_activity*/
	int trans_activity_t(edge* edgep,long double (*infection_time)());
	int trans_activity_t1(edge* edgep, long double(*infection_time)());
	/*network_generation*/
	int creat_random_network(int ave_degree);
	int creat_BA_network(int initnodenum,int stepedgenum);
	int import_1100(int node_type, int amountofnode, int amountofedge);
	int empty_all_edge();
	int empty_all_net();
	/*network_spread*/
	int init_node_state_t(int* infected,long double (*infection_time)(),long double (*recovery_time)());
	long double syn_t_sis_spread(long double(*infection_time)(), long double(*recovery_time)(), long double timestep);
	int init_node_state_t1(int* infected, long double(*infection_time)(), long double(*recovery_time)());
	long double syn_t1_sis_spread(long double(*infection_time)(), long double(*recovery_time)(), long double timestep);
};
/*txt_operator_class*/
/*
class txt_operator_out
{
private:
	ofstream txtfile;
public:
	txt_operator_out(string filename,int operate_type);
	int output_num(long double num,int decdigit,char addchar);
	int output_chars(string data);
	int output_char(char data);
	int close();
};*/
/*usual_functions*/
int uncompare(long double x,long double y);
int uncompare1(long double x,long double y);
long long int ipow(int x,int y);
int ilog(long long int x,long long int y);
long long int outputfrandnum(long long int max);
int fpossibility(long double rand,long long int acc);