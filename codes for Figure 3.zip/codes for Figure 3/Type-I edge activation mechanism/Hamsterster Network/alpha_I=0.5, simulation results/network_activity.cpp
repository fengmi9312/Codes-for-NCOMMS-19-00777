#include"network.h"
using namespace std;
int network::trans_activity_t(edge* edgep,long double (*infection_time)())
{
	int state0,state1;
	long double temp_time;
	state0=node_pointer[edgep->node_num].state;
	state1=node_pointer[edgep->target_node_num].state;
	if(state0==2||state1==2) 
	{
		edgep->activity=-1;
		edgep->time=-1;
		edgep->brother_edge->activity=-1;
		edgep->brother_edge->time=-1;
	}
	else if((state0==0&&state1==0)||(state0==1&&state1==1))
	{
		edgep->activity=0;
		edgep->time=-1;
		edgep->brother_edge->activity=0;
		edgep->brother_edge->time=-1;
	}
	else if((state0==0&&state1==1)||(state0==1&&state1==0))
	{
		temp_time=infection_time()+network_time;
		if(state0==1&&state1==0)
		{
			edgep->activity = 1;
			edgep->brother_edge->activity = 0;
			edgep->time=temp_time;
			edgep->brother_edge->time=-1;
		}
		else
		{
			edgep->activity = 0;
			edgep->brother_edge->activity = 1;
			edgep->time=-1;
			edgep->brother_edge->time=temp_time;
		}
	}
	edgep->b_time=network_time;
	return 1;
}
int network::trans_activity_t1(edge* edgep, long double(*infection_time)())
{
	int state0, state1;
	long double temp_time;
	if (node_pointer[edgep->node_num].state == 2 || node_pointer[edgep->node_num].state == 0)
	{
		edgep->activity = -1;
		edgep->time = -1;
	}
	else
	{
		edgep->activity = 1;
		edgep->time = infection_time() + network_time;
	}
	edgep->b_time = network_time;
	return 1;
}