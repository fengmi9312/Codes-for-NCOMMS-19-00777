#include<iostream>
#include<math.h>
#include<fstream>
#include<stdlib.h>
#include"network.h"
using namespace std;
int ilog(long long int x,long long int y)
{
	if(x<=0||y<=0)
	{
		cout<<"error network?ilog:: x or y blow or equal 0!"<<endl;
		return -1;
	}
	long long int temp;
	int i=0;
	temp=x;
	while(temp<=y)
	{
	    temp=temp*x;
		i++;
	}
	return i;
}
long long int outputfrandnum(long long int max)
{
	int i;
	int length;
    long long int num;
	if(max<=0) return -1;
	length=ilog(2,max)+1;
	do
	{
		num=0;
        for(i=0;i<length;i++)
	    {
    	     num=num*2+rand()%2;
    	}
	}while(num>=max);
	return num;
}
int fpossibility(long double rand,long long int acc)
{
	long long int randint;
	long long int num;
	num=outputfrandnum(acc);
	randint=(long long int)(rand*(long double)acc);
	if(num<=randint) return 1;
	else return 0;
}