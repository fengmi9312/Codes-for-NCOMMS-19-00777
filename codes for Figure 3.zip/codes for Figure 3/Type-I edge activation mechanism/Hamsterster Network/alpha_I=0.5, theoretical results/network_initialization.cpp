#include<iostream>
#include<math.h>
#include"network.h"
using namespace std;
network::network(int num)
{
	node_pointer=new node[num];
	node_amount=num;
	edge_amount=0;
	int i;
}

int network::init_function_rule1(int len, long double time_step, long double alpha1, long double beta1, long double alpha2, long double beta2)
{
	temp_matrix_length = len;
	timestep = time_step;
	infect_function = new long double[len];
	recover_function = new long double[len];
	int i, j;
	for (i = 0; i < len; i++)
	{
		if (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) == 0) infect_function[i] = 1;
		else infect_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta1, alpha1))) / pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1));
		if (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) == 0) recover_function[i] = 1;
		else recover_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta2, alpha2))) / pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2));
	}
	return 1;
}