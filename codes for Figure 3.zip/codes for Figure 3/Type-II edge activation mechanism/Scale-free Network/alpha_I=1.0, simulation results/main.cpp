#include<iostream>
#include<fstream>
#include<math.h>
#include<stdlib.h>
#include"network.h"
using namespace std;


long double a1 = 0, b1 = 0, a2 = 0, b2 = 0;
long double infection()
{
	return b1 * pow((log(100000.0) - log((long double)outputfrandnum(100000))) / log(2.718), 1 / a1);
}

long double recovery()
{
	return b2 * pow((log(100000.0) - log((long double)outputfrandnum(100000))) / log(2.718), 1 / a2);
}
int main()
{
//	string folder_name, folder_name2;
	long double time_limit = 6;
	int times = 100;
	a1 = 1;
	b1 = 1;
	a2 = 2;
	b2 = 0.5;
//	cout << "please input the value of a1:";
//	cin >> a1;
	//	cout << "please input the name of the folder:";
	//	cin >> folder_name;
	//if (a1 == 0.5) folder_name = "05";
//	else if (a1 == 1) folder_name = "10";
//	else if (a1 == 2) folder_name = "20";
//	else if (a1 == 4) folder_name = "40";
//	else system("pause");
//	b1 = 1;
	fstream fout1("experiment_quench_result.txt", ios::out);
	network net(10000);
	net.creat_BA_network(15, 5);
	int i, j, y, k, temp_, t;
	long double time = 0;
	long double array_temp[6100];
	int i_init[101];
	int r_init[1];
	r_init[0] = 0;
	i_init[0] = 100;
	for (k = 0; k < 6100; k++)
	{
		array_temp[k] = 0;
	}
	for (k = 0; k < times; k++)
	{
//		cout << k << endl;
		net.empty_all_state();
		t = 0;
		for (i = 1; i <= i_init[0]; i++)
		{
			do {
				y = 0;
				temp_ = outputfrandnum(net.output_node_amount());
				for (j = 1; j < i; j++)
				{
					if (i_init[j] == temp_) y = 1;
				}
			} while (y == 1);
			i_init[i] = temp_;
		}
		net.init_node_state_t1(i_init, infection, recovery);
		array_temp[t] += (long double)net.output_node_infected_amount() / (long double)net.output_node_amount();
		while (net.output_network_time() <= time_limit)
		{
			t++;
			net.syn_t1_sis_spread(infection, recovery, 0.001);
//			cout << net.output_node_infected_amount() << endl;
			if (net.output_node_infected_amount() == 0) break;
			array_temp[t] += (long double)net.output_node_infected_amount() / (long double)net.output_node_amount();
		}
	}
	for (i = 0; i <= t; i++)
	{
		array_temp[i] /= (long double)times;
		fout1 << ((long double)i)*0.001 << " " << array_temp[i] << endl;
	}
	return 1;
}