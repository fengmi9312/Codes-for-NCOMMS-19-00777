#include<math.h>
#include<fstream>
#include<stdlib.h>
#include"network.h"
using namespace std;

int network::init(long double init_infection)
{
	int i;
	for (i = 0; i < node_amount; i++)
	{
		node_pointer[i].infection_num = init_infection;
		node_pointer[i].suscept_num = 1 - init_infection;
	}
	return 1;
}
int network::spread_num(long double gamma, long double mu, long double time_step)
{
	int i;
	edge* edgep;
	long double affect;
	for (i = 0; i < node_amount; i++)
	{
		node_pointer[i].effect_temp = 1;
		edgep = node_pointer[i].first_edge_pointer;
		while (edgep)
		{
			node_pointer[i].effect_temp *= (1.0 - node_pointer[edgep->target_node_num].infection_num*gamma*time_step);
			edgep = edgep->next_edge;
		}
		node_pointer[i].effect_temp = 1.0 - node_pointer[i].effect_temp;
	}
	for (i = 0; i < node_amount; i++)
	{
		affect = node_pointer[i].suscept_num*node_pointer[i].effect_temp - mu * time_step*node_pointer[i].infection_num;
		node_pointer[i].infection_num = node_pointer[i].infection_num + affect;
		node_pointer[i].suscept_num = node_pointer[i].suscept_num - affect;
	}
	return 1;
}
long double network::output_infection()
{
	int i;
	long double temp = 0;
	for (i = 0; i < node_amount; i++)
	{
		temp += node_pointer[i].infection_num;
	}
	temp /= ((long double)node_amount);
	return temp;
}

long double network::output_suscept()
{
	int i;
	long double temp = 0;
	for (i = 0; i < node_amount; i++)
	{
		temp += node_pointer[i].suscept_num;
	}
	temp /= ((long double)node_amount);
	return temp;
}