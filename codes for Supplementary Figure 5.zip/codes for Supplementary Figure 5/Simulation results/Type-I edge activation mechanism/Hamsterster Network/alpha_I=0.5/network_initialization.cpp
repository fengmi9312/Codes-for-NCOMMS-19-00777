#include"network.h"
using namespace std;
network::network(int num)
{
	node_pointer=new node[num];
	node_amount=num;
	edge_amount=0;
	node_infected_amount=0;
	node_susceptible_amount=num;
	network_time=0;
}

int network::del_all_mark()
{
	int i;
	for (i = 0; i < node_amount; i++)
	{
		node_pointer[i].i_birth_mark = 0;
		node_pointer[i].s_birth_mark = 0;
	}
	return 1;
}