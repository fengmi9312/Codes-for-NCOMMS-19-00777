#include<iostream>
#include<fstream>
#include<string>
#include<math.h>
#include"network.h"
using namespace std;

class balance_detector {
private:
	int lenth;
	int possition;
	int balance;
	int full;
	long double* data_array;
public:
	int init(int array_lenth);
	int add_data(long double data);
	int balance_judge();
};
int balance_detector::init(int array_lenth)
{
	data_array = new long double[array_lenth];
	lenth = array_lenth;
	possition = -1;
	balance = 0;
	full = 0;
	int i;
	for (i = 0; i < lenth; i++) data_array[i] = 0;
	return 1;
}
int balance_detector::add_data(long double data)
{
	possition++;
	possition %= lenth;
	data_array[possition] = data;
	if (full == 0 && possition == lenth - 1) full = 1;
	return 1;
}
int balance_detector::balance_judge()
{
	if (full == 0) return 0;
	if (balance == 1) return 1;
	int i, i_temp;
	int num_0 = 0, num = 0;
	for (i = 1; i < lenth; i++)
	{
		i_temp = (possition + i) % lenth;
		if (i <= lenth / 2 && data_array[i_temp] >= data_array[possition]) num_0++;
		if (data_array[i_temp] >= data_array[possition]) num++;
	}
	if (num_0 >(lenth / 4 - 10) && num_0 < (lenth / 4 + 10) && num == lenth / 2)
	{
		balance = 1;
		return 1;
	}
	return 0;
}

long double a1 = 0, b1 = 0, a2 = 0, b2 = 0;
long double infection()
{
	return b1 * pow((log(100000.0) - log((long double)outputfrandnum(100000))) / log(2.718), 1 / a1);
}

long double recovery()
{
	return b2 * pow((log(100000.0) - log((long double)outputfrandnum(100000))) / log(2.718), 1 / a2);
}
int main()
{
	long long int jishu=0;
	long double alpha1 = 2, beta1 = 1, alpha2 = 2, beta2 = 0.5;
	a1 = alpha1;
	b1 = beta1;
	a2 = alpha2;
	b2 = beta2;
	long double time_step = 0.001;
	network net(10);
	net.import_1100(1, 2426, 16631);
	int len1 = 10000;
	int i, j;
	fstream outi_e("i_e.txt", ios::out);
	fstream outs_e("s_e.txt", ios::out);
	int i_init[101];
	int r_init[1];
	int possition_i;
	r_init[0] = 0;
	i_init[0] = 100;
	int temp_, y, k;
	long double* i_e_d = new long double[len1];
	long double* s_e_d = new long double[len1];
	int times = 1000;
	int state_amount;
	long double p_temp;
	for (i = 1; i <= 100; i++)
	{
		do {
			y = 0;
			temp_ = outputfrandnum(2426);
			for (j = 1; j < i; j++)
			{
				if (i_init[j] == temp_) y = 1;
			}
		} while (y == 1);
		i_init[i] = temp_;
	}
	balance_detector balance;
	balance.init(500);
	net.init_node_state_t1(i_init, infection, recovery);
	balance.add_data((long double)net.output_node_infected_amount());
//	cout << net.output_network_time() << " " << ((long double)net.output_node_infected_amount()) / ((long double)net.output_node_amount()) << endl;
	while (1)
	{
		net.syn_t1_sis_spread(infection, recovery, time_step);
		jishu++;
//		cout << ((long double)net.output_node_infected_amount()) / ((long double)net.output_node_amount()) << endl;
		if (jishu % 10 == 0)
		{
			balance.add_data((long double)net.output_node_infected_amount());
			if (balance.balance_judge() == 1) break;
		}
	}
	for (i = 0; i < len1; i++)
	{
		i_e_d[i] = 0;
		s_e_d[i] = 0;
	}
	net.del_all_mark();
	for (i = 0; i < times; i++)
	{
		net.syn_t1_sis_spread_no_time(infection, recovery, time_step);
//		cout << i << " " << ((long double)net.output_node_infected_amount()) / ((long double)net.output_node_amount()) << endl;
		for (k = 0; k < net.output_node_amount(); k++)
		{
			if (net.output_mark(k, 0) != 0 || net.output_mark(k, 1) != 0)
			{
				if (net.output_mark(k, 0) != 0) s_e_d[0] += ((long double)net.output_mark(k, 0)) / (long double)net.output_node_amount() / time_step / (long double)times;
				if (net.output_mark(k, 1) != 0) i_e_d[0] += ((long double)net.output_mark(k, 1)) / (long double)net.output_node_amount() / time_step / (long double)times;
			}
			else
			{
				p_temp = net.output_e_time(k, 0);
				if (p_temp > -0.4)
				{
					possition_i = (int)(p_temp / time_step);
					if (ffabs(p_temp - ((long double)(possition_i + 1))*time_step) < 0.4*time_step)
					{
						if (possition_i + 1 < len1) s_e_d[possition_i + 1] += 1.0 / (long double)net.output_node_amount() / time_step / (long double)times;
					}
					else if (ffabs(p_temp - ((long double)possition_i)*time_step) < 0.4*time_step)
					{
						if (possition_i < len1) s_e_d[possition_i] += 1.0 / (long double)net.output_node_amount() / time_step / (long double)times;
					}
					//				else system("pause");
				}
				p_temp = net.output_e_time(k, 1);
				if (p_temp > -0.4)
				{
					possition_i = (int)(p_temp / time_step);
					if (ffabs(p_temp - ((long double)(possition_i + 1))*time_step) < 0.4*time_step)
					{
						if (possition_i + 1 < len1) i_e_d[possition_i + 1] += 1.0 / (long double)net.output_node_amount() / time_step / (long double)times;
					}
					else if (ffabs(p_temp - ((long double)possition_i)*time_step) < 0.4*time_step)
					{
						if (possition_i < len1) i_e_d[possition_i] += 1.0 / (long double)net.output_node_amount() / time_step / (long double)times;
					}
					//				else system("pause");
				}
			}
//			if ((net.output_e_time(k, 0) + time_step > 0 && net.output_e_time(k, 0) + time_step < time_step) || (net.output_e_time(k, 1) + time_step >= 0 && net.output_e_time(k, 1) + time_step < time_step))
//			{
//				system("pause");
//				net.output_e_time(k, 0);
//				net.output_e_time(k, 1);
//			}
		}
		net.del_all_mark();
		net.update_network_time(time_step);
	}
	for (i = 0; i < len1; i++)
	{
		outi_e << ((long double)i)*time_step << " " << i_e_d[i] << endl;
		outs_e << ((long double)i)*time_step << " " << s_e_d[i] << endl;
	}
	return 1;
}