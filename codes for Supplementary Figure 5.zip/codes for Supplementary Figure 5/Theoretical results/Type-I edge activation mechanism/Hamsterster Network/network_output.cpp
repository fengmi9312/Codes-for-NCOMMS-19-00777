#include<iostream>
#include<math.h>
#include<stdlib.h>
#include"network.h"
using namespace std;
int network::output_node_amount()
{
	return node_amount;
}
long double network::output_max_eigenvalue()
{
	int i,k;
	long double max_temp;
	long double temp,temp1;
	edge* edgep;
	long double* vector = new long double[node_amount]; 
	long double* vector_temp = new long double[node_amount];
	for (i = 0; i < node_amount; i++)
	{
		vector[i] = (long double)outputfrandnum(10000) + 1;
		vector_temp[i] = 0;
	}
	max_temp = 0;
	for (i = 0; i < node_amount; i++)
	{
		if (vector[i] > max_temp) max_temp = vector[i];
	}
	for (i = 0; i < node_amount; i++)
	{
		vector[i] /= max_temp;
	}
	while (1)
	{
		temp = 0;
		temp1 = 0;
		for (i = 0; i < node_amount; i++)
		{
			edgep = node_pointer[i].first_edge_pointer;
			while (edgep)
			{
				vector_temp[i] += vector[edgep->target_node_num];
				edgep = edgep->next_edge;
			}
		}
		for (i = 0; i < node_amount; i++)
		{
			temp += vector_temp[i] / vector[i];
		}
		temp /= (long double)node_amount;
		k = 1;
		for (i = 0; i < node_amount; i++)
		{
			if (abs(temp - vector_temp[i] / vector[i]) > 0.0001)
			{
				k = 0;
				break;
			}
		}
//		cout << temp << endl;
		if (k == 1) break;
		max_temp = 0;
		for (i = 0; i < node_amount; i++)
		{
			vector[i] = vector_temp[i];
			vector_temp[i] = 0;
			if (vector[i] > max_temp) max_temp = vector[i];
		}
		for (i = 0; i < node_amount; i++)
		{
			vector[i] /= max_temp;
		}
	}
	return temp;
}

long double network::output_node_array_infect_new(int num)
{
	int i;
	long double temp = 0;
	for (i = 0; i < temp_matrix_length; i++)
	{
		temp += node_pointer[num].infect_array[i] * timestep;
	}
	return temp;
}
long double network::output_node_array_suscept_new(int num)
{
	int i;
	long double temp = 0;
	for (i = 0; i < temp_matrix_length; i++)
	{
		temp += node_pointer[num].suscept_array[i] * timestep;
	}
	return temp;
}

long double network::output_all_node_array_infect_new()
{
	int i;
	long double temp = 0;
	for (i = 0; i < node_amount; i++) temp += output_node_array_infect_new(i);
	return temp / node_amount;
}
long double network::output_all_node_array_suscept_new()
{
	int i;
	long double temp = 0;
	for (i = 0; i < node_amount; i++) temp += output_node_array_suscept_new(i);
	return temp / node_amount;
}
