#include<iostream>
#include<math.h>
#include<stdlib.h>
#include"network.h"
using namespace std;


long double* network::output_all_i_distribution()
{
	int i, j;
	long double* temp;
	temp = new long double[temp_matrix_length];
	for (j = 0; j < temp_matrix_length; j++)
	{
		temp[j] = 0;
	}
	for (i = 0; i < node_amount; i++)
	{
		for (j = 0; j < temp_matrix_length; j++)
		{
			temp[j] += (node_pointer[i].infect_array[j] / ((long double)node_amount));
		}
	}
	return temp;
}
long double* network::output_all_s_distribution()
{
	int i, j;
	long double* temp;
	temp = new long double[temp_matrix_length];
	for (j = 0; j < temp_matrix_length; j++)
	{
		temp[j] = 0;
	}
	for (i = 0; i < node_amount; i++)
	{
		for (j = 0; j < temp_matrix_length; j++)
		{
			temp[j] += (node_pointer[i].suscept_array[j] / ((long double)node_amount));
		}
	}
	return temp;
}