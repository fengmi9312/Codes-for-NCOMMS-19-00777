#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include"network_element.h"
using namespace std;
/*usual_structure*/

class network
{
private:
	node* node_pointer;
	int node_amount;
	int edge_amount;
	long double* infect_function;
	long double* recover_function;
	long double* infect_age_distribution;
	long double* suscept_age_distribution;
	int temp_matrix_length;
	long double timestep;
	
public:
	int coutf();
	/*network_initial*/
	network(int num);
	int init_function_rule1(int len, long double time_step, long double alpha1, long double beta1, long double alpha2, long double beta2);
	int init_function_rule1_new_pre(int len);
	int init_function_rule1_new(long double time_step, long double alpha1, long double beta1, long double alpha2, long double beta2);
	/*network_output*/
	int output_node_amount();
	long double output_node_array_infect_new(int num);
	long double output_all_node_array_infect_new();
	long double output_node_array_infect_new_new(int num,int temp_len);
	long double output_all_node_array_infect_new_new(int temp_len);
	long double output_node_array_suscept_new(int num);
	long double output_all_node_array_suscept_new();
	long double output_max_eigenvalue();
	long double* output_all_i_distribution();
	long double* output_all_s_distribution();
	/*network_property*/
	double n_order_moment(int n);
/*	int output_age_distribution(string filename, string filename1);*/
	/*network_operator*/
	int add_edge1(int node0_num, int node1_num);
	int add_edge(int i,int j,int direction,double weight);
	/*network_generation*/
	int creat_random_network(int ave_degree);
	int creat_BA_network(int initnodenum,int stepedgenum);
	int empty_all_edge();
	int empty_all_net();
	int import_1100(int node_type, int amountofnode, int amountofedge);
	/*network_dynamical_process*/
	int init_rule1_process(long double init);
	int init_rule1_process_new_pre();
	int init_rule1_process_new(long double init);
	int re_init_rule1_process(long double init);
	int dynamical_rule1();
	int dynamical_rule1_new(int temp_len);
};
long long int outputfrandnum(long long int max);

