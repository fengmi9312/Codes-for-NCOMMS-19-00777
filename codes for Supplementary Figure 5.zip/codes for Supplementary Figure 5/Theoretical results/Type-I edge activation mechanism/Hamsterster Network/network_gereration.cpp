#include<math.h>
#include<fstream>
#include<stdlib.h>
#include"network.h"
using namespace std;
int network::creat_random_network(int ave_degree)
{
	int i,j;
	for(i=0;i<node_amount;i++)
		for(j=0;j<ave_degree;j++)
			add_edge(i,outputfrandnum(node_amount*10)/10,0,1);
	return 1;
}
int network::creat_BA_network(int initnodenum,int stepedgenum)
{
    int i,j,k,t,e,udgr;
	int* p;
	long long int num;
	if(initnodenum<stepedgenum)
	{
//		cout<<"error undirected?creatsfnet:initnodenum<stepedgenum!"<<endl;
		return 0;
	}
	if(initnodenum==1);
	else if(initnodenum==2) add_edge1(0,1);
	else if(initnodenum<=0) 
	{
//		cout<<"error undirected?creatsfnet:initnodenum<=0!"<<endl;
		return 0;
	}
	else
	{
        for(i=0;i<initnodenum;i++)
        {
	    	j=i+1;
	    	if(j==initnodenum) j=0;
            add_edge1(i,j);
        }
	}
	p=(int*)malloc(stepedgenum*sizeof(int));
	for(i=initnodenum;i<node_amount;i++)
	{
        for(j=0;j<stepedgenum;j++)
        {
	        do{
	    	     num=outputfrandnum(edge_amount*2);
	    	     for(k=0;k<i;k++)
	    	     {
					 udgr=node_pointer[k].degree;
	    	 		 num=num-udgr;
				 	 if(num<0) break;
	    	     }
				 e=0;
				 for(t=0;t<j;t++)
				 {
					 if(p[t]==k)
					 {
						 e=1;
						 break;
					 }
				 }
	         }while(e==1);
			 p[j]=k;
         }
		for(j=0;j<stepedgenum;j++) add_edge1(i,p[j]);
	}
	free(p);
    return 1;
}


int network::empty_all_edge()
{
	int i;
	edge* edgep;
	edge* temp;
	for (i = 0; i<node_amount; i++)
	{
		node_pointer[i].degree = 0;
		temp = node_pointer[i].first_edge_pointer;
		while (temp)
		{
			edgep = temp;
			temp = edgep->next_edge;
			delete edgep;
		}
		node_pointer[i].first_edge_pointer = NULL;
	}
	edge_amount = 0;
	return 1;
}
int network::empty_all_net()
{
	empty_all_edge();
	delete node_pointer;
	node_amount = 0;
	return 1;
}
int network::import_1100(int node_type, int amountofnode, int amountofedge)
{
	ifstream txtfile("real_network.txt", ios::in);
	int i, j;
	int node0, node1;
	empty_all_net();
	edge_amount = 0;
	i = 0;
	node_amount = amountofnode;
	node_pointer = new node[node_amount]();
	for (j = 0; j<amountofedge; j++)
	{
		txtfile >> node0;
		txtfile >> node1;
		if (node_type == 1)
		{
			node0--;
			node1--;
		}
		add_edge(node0, node1, 0, 1);
	}
	txtfile.close();
	return 1;
}