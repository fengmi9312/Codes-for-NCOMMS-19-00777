#include<iostream>
#include<fstream>
#include"network.h"
using namespace std;
int main()
{
	int i,j, t;
	long double temp,timed;
	long double alpha1;
	long double* i_distribution;
	long double* s_distribution;
	fstream fout05_i("05_i.txt", ios::out);
	fstream fout10_i("10_i.txt", ios::out);
	fstream fout20_i("20_i.txt", ios::out);
	fstream fout40_i("40_i.txt", ios::out);
	fstream fout05_s("05_s.txt", ios::out);
	fstream fout10_s("10_s.txt", ios::out);
	fstream fout20_s("20_s.txt", ios::out);
	fstream fout40_s("40_s.txt", ios::out);
	network net(10000);
	net.creat_random_network(5);
	net.init_function_rule1_new_pre(3500);
	net.init_rule1_process_new_pre();
	for (i = 1; i <= 4; i++)
	{
		if (i == 1) alpha1 = 0.5;
		else if (i == 2) alpha1 = 1.0;
		else if (i == 3) alpha1 = 2.0;
		else alpha1 = 4.0;
		net.init_function_rule1_new(0.01, alpha1, 1, 2, 0.5);
		net.init_rule1_process_new(0.01);
		t = 0;
		timed = 0;
		while(timed<=30)
		{
			timed += 0.01;
			//cout << timed <<" "<<net.output_all_node_array_infect_new()<< endl;
			t++;
			net.dynamical_rule1_new(t);
		}
		i_distribution = net.output_all_i_distribution();
		s_distribution = net.output_all_s_distribution();
		if (i == 1)
		{
			for (j = 0; j <= 600; j++)
			{
				fout05_i << ((long double)j)*0.01 << " " << i_distribution[j] << endl;
				fout05_s << ((long double)j)*0.01 << " " << s_distribution[j] << endl;
			}
		}
		else if (i == 2)
		{
			for (j = 0; j <= 600; j++)
			{
				fout10_i << ((long double)j)*0.01 << " " << i_distribution[j] << endl;
				fout10_s << ((long double)j)*0.01 << " " << s_distribution[j] << endl;
			}
		}
		else if (i == 3)
		{
			for (j = 0; j <= 600; j++)
			{
				fout20_i << ((long double)j)*0.01 << " " << i_distribution[j] << endl;
				fout20_s << ((long double)j)*0.01 << " " << s_distribution[j] << endl;
			}
		}
		else
		{
			for (j = 0; j <= 600; j++)
			{
				fout40_i << ((long double)j)*0.01 << " " << i_distribution[j] << endl;
				fout40_s << ((long double)j)*0.01 << " " << s_distribution[j] << endl;
			}
		}
		delete i_distribution;
		delete s_distribution;
	}
	return 1;
}