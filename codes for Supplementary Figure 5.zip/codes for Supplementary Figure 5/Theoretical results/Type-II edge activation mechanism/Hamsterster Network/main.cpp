#include"network.h"
#include<iostream>
#include<math.h>
#include<fstream>
using namespace std;

long double infect_function[5301];
long double recover_function[5301];
long double trans_infect_function[5301];
int init_in_su(long double alpha1, long double beta1, long double alpha2, long double beta2, long double time_step)
{
	int i, j;
	for (i = 0; i < 5301; i++)
	{
		if (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) == 0) infect_function[i] = 1;
		else infect_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta1, alpha1))) / pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1));
		if (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) == 0) recover_function[i] = 1;
		else recover_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta2, alpha2))) / pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2));
	}
	for (j = 0; j < 5300; j++)
	{
		trans_infect_function[j] = pow(2.718, -pow(((long double)j)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(j + 1))*time_step / beta1, alpha1));
		for (i = 0; i < j; i++)
		{
			trans_infect_function[j] += trans_infect_function[i] * (pow(2.718, -pow(((long double)(j - i - 1))*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(j - i))*time_step / beta1, alpha1)));
		}
	}
	return 1;
}
int main()
{
	int i,j, t;
	long double timed,temp;
	long double alpha1;
	long double* i_distribution;
	long double* s_distribution;
	fstream fout05_i("05_i.txt", ios::out);
	fstream fout10_i("10_i.txt", ios::out);
	fstream fout20_i("20_i.txt", ios::out);
	fstream fout40_i("40_i.txt", ios::out);
	fstream fout05_s("05_s.txt", ios::out);
	fstream fout10_s("10_s.txt", ios::out);
	fstream fout20_s("20_s.txt", ios::out);
	fstream fout40_s("40_s.txt", ios::out);
	network net(10);
	net.import_1100(1, 2426, 16631);
	net.init_array_new_pre(3300);
	for (i = 1; i <= 4; i++)
	{
		if (i == 1) alpha1 = 0.5;
		else if (i == 2) alpha1 = 1.0;
		else if (i == 3) alpha1 = 2.0;
		else alpha1 = 4.0;
		init_in_su(alpha1, 1, 2, 0.5, 0.01);
		net.init_array_new(24.0 / 2426.0);
		timed = 0;
		t = 0;
		while (timed < 30)
		{
			timed += 0.01;
			t++;
			net.dynamic_rule2_new(recover_function, trans_infect_function, t);
		}
		i_distribution = net.output_all_distribution_i(700);
		s_distribution = net.output_all_distribution_s(700);
		if (i == 1)
		{
			for (j = 0; j <= 600; j++)
			{
				fout05_i << ((long double)j)*0.01 << " " << i_distribution[j] << endl;
				fout05_s << ((long double)j)*0.01 << " " << s_distribution[j] << endl;
			}
		}
		else if (i == 2)
		{
			for (j = 0; j <= 600; j++)
			{
				fout10_i << ((long double)j)*0.01 << " " << i_distribution[j] << endl;
				fout10_s << ((long double)j)*0.01 << " " << s_distribution[j] << endl;
			}
		}
		else if (i == 3)
		{
			for (j = 0; j <= 600; j++)
			{
				fout20_i << ((long double)j)*0.01 << " " << i_distribution[j] << endl;
				fout20_s << ((long double)j)*0.01 << " " << s_distribution[j] << endl;
			}
		}
		else
		{
			for (j = 0; j <= 600; j++)
			{
				fout40_i << ((long double)j)*0.01 << " " << i_distribution[j] << endl;
				fout40_s << ((long double)j)*0.01 << " " << s_distribution[j] << endl;
			}
		}
		delete i_distribution;
		delete s_distribution;
	}
	return 1;
}
