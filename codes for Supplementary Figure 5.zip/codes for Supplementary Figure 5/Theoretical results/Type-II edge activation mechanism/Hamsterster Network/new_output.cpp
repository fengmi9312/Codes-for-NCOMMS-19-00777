#include<iostream>
#include<math.h>
#include"network.h"
using namespace std;


long double* network::output_all_distribution_i(int area)
{
	long double* i_distribution;
	int i, j;
	i_distribution = new long double[area + 1];
	for (j = 0; j <= area; j++)
	{
		i_distribution[j] = 0;
	}
	for (i = 0; i < node_amount; i++)
	{
		for (j = 0; j <= area; j++)
		{
			i_distribution[j] += (node_pointer[i].infect_array[j] / ((long double)node_amount));
		}
	}
	return i_distribution;
}
long double* network::output_all_distribution_s(int area)
{
	long double* s_distribution;
	int i, j;
	s_distribution = new long double[area + 1];
	for (j = 0; j <= area; j++)
	{
		s_distribution[j] = 0;
	}
	for (i = 0; i < node_amount; i++)
	{
		for (j = 0; j <= area; j++)
		{
			s_distribution[j] += (node_pointer[i].suscept_array[j] / ((long double)node_amount));
		}
	}
	return s_distribution;
}