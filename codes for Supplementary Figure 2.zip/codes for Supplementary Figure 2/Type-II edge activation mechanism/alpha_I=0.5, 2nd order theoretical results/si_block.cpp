#include<iostream>
#include<math.h>
#include"header.h"
using namespace std;

si_block::si_block()
{
	value = 0;
	value_temp = 0;
}

int si_block::lost(long double* omega_tau_1, long double* omega_kappa_2, long double* omega_tau_2, long double _timestep)
{
	func_pointer->get_si_pointer(tau_1 + 1, kappa_2 + 1, tau_2 + 1)->value_temp += (1 - omega_tau_1[tau_1])*(1 - omega_kappa_2[kappa_2])*(1 - omega_tau_2[tau_2])*value;
	func_pointer->get_ii_pointer(0, kappa_2 + 1, tau_2 + 1)->value_temp += omega_tau_1[tau_1] * (1 - omega_kappa_2[kappa_2])*(1 - omega_tau_2[tau_2])*value;
	func_pointer->get_ii_pointer(0, 0, tau_2 + 1)->value_temp += (1 - omega_tau_1[tau_1])*omega_kappa_2[kappa_2] * (1 - omega_tau_2[tau_2])*value;
	func_pointer->get_ss_pointer(tau_1 + 1, 0)->value_temp += (1 - omega_tau_1[tau_1])*(1 - omega_kappa_2[kappa_2])*omega_tau_2[tau_2]*value*_timestep;
	func_pointer->get_ii_pointer(0, 0, tau_2 + 1)->value_temp += omega_tau_1[tau_1] * omega_kappa_2[kappa_2] * (1 - omega_tau_2[tau_2])*value;
	//omega_tau_1[tau_1] * (1 - omega_kappa_2[kappa_2])*omega_tau_2[tau_2] * value;
	//(1 - omega_tau_1[tau_1])*omega_kappa_2[kappa_2]*omega_tau_2[tau_2]*value;
	//omega_tau_1[tau_1] * omega_kappa_2[kappa_2] * omega_tau_2[tau_2] * value;

	//(1 - omega_tau_1[tau_1])*(1 - omega_kappa_2[kappa_2])*(1 - omega_tau_2[tau_2])*value;
	func_pointer->get_ii_pointer(tau_2 + 1, 0, 0)->value_temp += omega_tau_1[tau_1] * (1 - omega_kappa_2[kappa_2])*(1 - omega_tau_2[tau_2])*value;
	func_pointer->get_ii_pointer(tau_2 + 1, 0, 0)->value_temp += (1 - omega_tau_1[tau_1])*omega_kappa_2[kappa_2] * (1 - omega_tau_2[tau_2])*value;
	func_pointer->get_ss_pointer(0, tau_1 + 1)->value_temp += (1 - omega_tau_1[tau_1])*(1 - omega_kappa_2[kappa_2])*omega_tau_2[tau_2] * value*_timestep;
	func_pointer->get_ii_pointer(tau_2 + 1, 0, 0)->value_temp += omega_tau_1[tau_1] * omega_kappa_2[kappa_2] * (1 - omega_tau_2[tau_2])*value;
	func_pointer->get_si_pointer(0, 0, 0)->value_temp += omega_tau_1[tau_1] * (1 - omega_kappa_2[kappa_2])*omega_tau_2[tau_2] * value;
	func_pointer->get_si_pointer(0, 0, 0)->value_temp += (1 - omega_tau_1[tau_1])*omega_kappa_2[kappa_2] * omega_tau_2[tau_2] * value;
	func_pointer->get_si_pointer(0, 0, 0)->value_temp += omega_tau_1[tau_1] * omega_kappa_2[kappa_2] * omega_tau_2[tau_2] * value;
	return 1;
}

int si_block::renew()
{
	value = value_temp;
	value_temp = 0;
	return 1;
}

long double si_block::get_value()
{
	return value;
}