#include<iostream>
#include<math.h>
#include"header.h"
using namespace std;

s_block::s_block()
{
	value = 0;
	value_temp = 0;
}

int s_block::lost(long double* omega_tau,long double _timestep)
{
	func_pointer->get_s_pointer(tau + 1)->value_temp += (1 - omega_tau[tau])*value;
	func_pointer->get_i_pointer(0, 0)->value_temp += omega_tau[tau]*value/_timestep;
	return 1;
}

int s_block::renew()
{
	value = value_temp;
	value_temp = 0;
	return 1;
}

long double s_block::get_value()
{
	return value;
}