#include<iostream>
#include<math.h>
#include"header.h"
using namespace std;
i_block::i_block()
{
	value = 0;
	value_temp = 0;
}

int i_block::lost(long double* omega_kappa,long double* omega_tau, long double _timestep)
{
	func_pointer->get_i_pointer(kappa + 1, tau + 1)->value_temp += (1 - omega_tau[tau])*(1 - omega_kappa[kappa])*value;
	func_pointer->get_i_pointer(0, tau + 1)->value_temp += omega_kappa[kappa] * (1 - omega_tau[tau])*value;
	func_pointer->get_s_pointer(0)->value_temp += (1 - omega_kappa[kappa])*omega_tau[tau] * value*_timestep;
	func_pointer->get_s_pointer(0)->value_temp += omega_kappa[kappa]*omega_tau[tau]*value*_timestep;
	return 1;
}

int i_block::renew()
{
	value = value_temp;
	value_temp = 0;
	return 1;
}

long double i_block::get_value()
{
	return value;
}