#include<iostream>
#include<math.h>
#include"header.h"
using namespace std;

func::func(long double _timestep, int _len,long double ave_degree)
{
	int i, j, k;
	recovery_rate = NULL;
	transmission_rate = NULL;
	infection_rate_pair = NULL;
	infection_rate_node = NULL;
	degree = ave_degree;
	time = 0;
	timestep = _timestep;
	len = _len;

	recovery_rate = new long double[len];
	transmission_rate = new long double[len];
	infection_rate_pair = new long double[len];
	infection_rate_node = new long double[len];
	i_pointer = new i_block*[len];
	s_pointer = new s_block[len];
	ii_pointer = new ii_block**[len];
	si_pointer = new si_block**[len];
	ss_pointer = new ss_block*[len];
	for (i = 0; i < len; i++)
	{
		s_pointer[i].tau = i;
		s_pointer[i].func_pointer = this;
		i_pointer[i] = new i_block[len];
		ii_pointer[i] = new ii_block*[len];
		si_pointer[i] = new si_block*[len];
		ss_pointer[i] = new ss_block[len];
		for (j = 0; j < len; j++)
		{
			i_pointer[i][j].kappa = i;
			i_pointer[i][j].tau = j;
			i_pointer[i][j].func_pointer = this;
			ss_pointer[i][j].tau_1 = i;
			ss_pointer[i][j].tau_2 = j;
			ss_pointer[i][j].func_pointer = this;
			ii_pointer[i][j] = new ii_block[len];
			si_pointer[i][j] = new si_block[len];
			for (k = 0; k < len; k++)
			{
				ii_pointer[i][j][k].tau_1 = i;
				ii_pointer[i][j][k].kappa_2 = j;
				ii_pointer[i][j][k].tau_2 = k;
				ii_pointer[i][j][k].func_pointer = this;
				si_pointer[i][j][k].tau_1 = i;
				si_pointer[i][j][k].kappa_2 = j;
				si_pointer[i][j][k].tau_2 = k;
				si_pointer[i][j][k].func_pointer = this;
			}
		}
	}
}

i_block* func::get_i_pointer(int kappa, int tau)
{
	return &i_pointer[kappa][tau];
}

s_block* func::get_s_pointer(int tau)
{
	return &s_pointer[tau];
}

ii_block* func::get_ii_pointer(int tau_1, int kappa_2, int tau_2)
{
	return &ii_pointer[tau_1][kappa_2][tau_2];
}

si_block* func::get_si_pointer(int tau_1, int kappa_2, int tau_2)
{
	return &si_pointer[tau_1][kappa_2][tau_2];
}

ss_block* func::get_ss_pointer(int tau_1, int tau_2)
{
	return &ss_pointer[tau_1][tau_2];
}

int func::generate_trans_rec(long double alpha1, long double beta1,long double alpha2, long double beta2)
{
	int i;
	for (i = 0; i < len; i++)
	{
		if (pow(2.718, -pow(((long double)i)*timestep / beta1, alpha1)) == 0) transmission_rate[i] = 1;
		else transmission_rate[i] = (pow(2.718, -pow(((long double)i)*timestep / beta1, alpha1)) - pow(2.718, -pow(((long double)(i + 1))*timestep / beta1, alpha1))) / pow(2.718, -pow(((long double)i)*timestep / beta1, alpha1));
		if (pow(2.718, -pow(((long double)i)*timestep / beta2, alpha2)) == 0) recovery_rate[i] = 1;
		else recovery_rate[i] = (pow(2.718, -pow(((long double)i)*timestep / beta2, alpha2)) - pow(2.718, -pow(((long double)(i + 1))*timestep / beta2, alpha2))) / pow(2.718, -pow(((long double)i)*timestep / beta2, alpha2));
	}
	generate_inf();
	return 1;
}

int func::generate_inf()
{
	int i, j, k;
	for (i = 0; i < len; i++)
	{
		if (i > time)
		{
			infection_rate_pair[i] = 0;
			infection_rate_node[i] = 0;
		}
		else
		{
			infection_rate_pair[i] = 0;
			infection_rate_node[i] = 0;
			for (j = 0; j <= time; j++)
			{
				for (k = 0; k <= j; k++)
				{
					infection_rate_pair[i] += transmission_rate[k] * si_pointer[i][k][j].get_value();
					infection_rate_node[i] += transmission_rate[k] * si_pointer[i][k][j].get_value();
				}
			}
			infection_rate_pair[i] = 1.0 - pow(1.0 - infection_rate_pair[i] * timestep*timestep / s_pointer[i].get_value(), degree - 1.0);
			infection_rate_node[i] = 1.0 - pow(1.0 - infection_rate_node[i] * timestep*timestep / s_pointer[i].get_value(), degree);
		}
	}
	return 1;
}

int func::init(long double init_rate)
{
	i_pointer[0][0].value_temp = init_rate/(timestep*timestep);
	s_pointer[0].value_temp = (1 - init_rate) / timestep;
	ii_pointer[0][0][0].value_temp = init_rate*init_rate / (timestep*timestep*timestep);
	si_pointer[0][0][0].value_temp = (1 - init_rate)*init_rate / (timestep*timestep*timestep);
	ss_pointer[0][0].value_temp = (1 - init_rate)*(1 - init_rate) / (timestep*timestep);
	renew_2();
	return 1;
}

int func::run()
{
	generate_inf();
	renew_1();
	renew_2();
	time++;
	return 1;
}

int func::renew_1()
{
	int i, j, k;
	for (i = 0; i <= time; i++)
	{
		s_pointer[i].lost(infection_rate_node, timestep);
		for (j = 0; j <= time; j++)
		{
			i_pointer[i][j].lost(transmission_rate, recovery_rate, timestep);
			ss_pointer[i][j].lost(infection_rate_pair, infection_rate_pair, timestep);
			for (k = 0; k <= j; k++)
			{
				ii_pointer[i][k][j].lost(recovery_rate, transmission_rate, recovery_rate, timestep);
				si_pointer[i][k][j].lost(infection_rate_pair, transmission_rate, recovery_rate, timestep);
			}
		}
	}
	return 1;
}

int func::renew_2()
{
	int i, j, k;
	for (i = 0; i <= time+1; i++)
	{
		s_pointer[i].renew();
		for (j = 0; j <= time+1; j++)
		{
			i_pointer[i][j].renew();
			ss_pointer[i][j].renew();
			for (k = 0; k <= j; k++)
			{
				ii_pointer[i][k][j].renew();
				si_pointer[i][k][j].renew();
			}
		}
	}
	return 1;
}

long double func::count_i()
{
	int i, j;
	long double temp;
	temp = 0;
	for (i = 0; i <= time; i++)
	{
		for (j = 0; j <= i; j++)
		{
			temp += i_pointer[j][i].get_value()*timestep*timestep;
		}
	}
	return temp;
}

long double func::count_s()
{
	int i;
	long double temp;
	temp = 0;
	for (i = 0; i <= time; i++)
	{
		temp += s_pointer[i].get_value()*timestep;
	}
	return temp;
}

long double func::count_ii()
{
	int i, j, k;
	long double temp;
	temp = 0;
	for (i = 0; i <= time; i++)
	{
		for (j = 0; j <= time; j++)
		{
			for (k = 0; k <= j; k++)
			{
				temp += ii_pointer[i][k][j].get_value()*timestep*timestep*timestep;
			}
		}
	}
	return temp;
}

long double func::count_si()
{
	int i, j, k;
	long double temp;
	temp = 0;
	for (i = 0; i <= time; i++)
	{
		for (j = 0; j <= time; j++)
		{
			for (k = 0; k <= j; k++)
			{
				temp += si_pointer[i][k][j].get_value()*timestep*timestep*timestep;
			}
		}
	}
	return temp;
}

long double func::count_ss()
{
	int i, j;
	long double temp;
	temp = 0;
	for (i = 0; i <= time; i++)
	{
		for (j = 0; j <= time; j++)
		{
			temp += ss_pointer[j][i].get_value()*timestep*timestep;
		}
	}
	return temp;
}

