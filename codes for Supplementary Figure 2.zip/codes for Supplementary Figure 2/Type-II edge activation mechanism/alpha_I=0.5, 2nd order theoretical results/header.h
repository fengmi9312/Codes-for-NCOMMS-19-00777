#pragma once
#include<iostream>
#include<math.h>
#include<string.h>
using namespace std;

class i_block;
class s_block; 
class ii_block; 
class si_block; 
class ss_block;
class func;

class i_block
{
private:
	long double value;
public:
	func* func_pointer;
	long double value_temp;
	int kappa;
	int tau;
	i_block();
	int lost(long double* omega_kappa, long double* omega_tau, long double _timestep);
	int renew();
	long double get_value();
};

class s_block
{
private:
	long double value;
public:
	long double value_temp;
	int tau;
	func* func_pointer;
	s_block();
	int lost(long double* omega_tau,long double _timestep);
	int renew();
	long double get_value();
};

class ii_block
{
private:
	long double value;
public:
	long double value_temp;
	int tau_1;
	int kappa_2;
	int tau_2;
	func* func_pointer;
	ii_block();
	int lost(long double* omega_tau_1, long double* omega_kappa_2, long double* omega_tau_2,long double _timestep);
	int renew();
	long double get_value();
}; 

class si_block
{
private:
	long double value;
public:
	long double value_temp;
	int tau_1;
	int kappa_2;
	int tau_2;
	func* func_pointer;
	si_block();
	int lost(long double* omega_tau_1, long double* omega_kappa_2, long double* omega_tau_2, long double _timestep);
	int renew();
	long double get_value();
};

class ss_block
{
private:
	long double value;
public:
	long double value_temp;
	int tau_1;
	int tau_2;
	func* func_pointer;
	ss_block();
	int lost(long double* omega_tau_1, long double* omega_tau_2, long double _timestep);
	int renew();
	long double get_value();
};

class func
{
private:
	int len;
	int time;
	long double timestep;
	long double degree;
	i_block** i_pointer;
	s_block* s_pointer;
	ii_block*** ii_pointer;
	si_block*** si_pointer;
	ss_block** ss_pointer;
	long double* recovery_rate;
	long double* transmission_rate;
	long double* infection_rate_pair;
	long double* infection_rate_node;
	int renew_1();
	int renew_2();
	int generate_inf();
public:
	func(long double _timestep, int _len, long double ave_degree);
	i_block* get_i_pointer(int kappa, int tau);
	s_block* get_s_pointer(int tau);
	ii_block* get_ii_pointer(int tau_1, int kappa_2, int tau_2);
	si_block* get_si_pointer(int tau_1, int kappa_2, int tau_2);
	ss_block* get_ss_pointer(int tau_1, int tau_2);
	int generate_trans_rec(long double alpha1, long double beta_1, long double alpha_2, long double beta_2);
	int init(long double init_rate);
	int run();
	long double count_i();
	long double count_s();
	long double count_ii();
	long double count_si();
	long double count_ss();
};