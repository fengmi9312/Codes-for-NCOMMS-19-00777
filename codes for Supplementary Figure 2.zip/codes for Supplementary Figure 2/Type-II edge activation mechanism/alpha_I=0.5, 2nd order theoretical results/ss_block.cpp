#include<iostream>
#include<math.h>
#include"header.h"
using namespace std;

ss_block::ss_block()
{
	value = 0;
	value_temp = 0;
}

int ss_block::lost(long double* omega_tau_1, long double* omega_tau_2,long double _timestep)
{
	func_pointer->get_ss_pointer(tau_1 + 1, tau_2 + 1)->value_temp += (1 - omega_tau_1[tau_1])*(1 - omega_tau_2[tau_2])*value;
	//func_pointer->get_is_pointer(tau_1 + 1, tau_2 + 1)->value_temp += omega_tau_1[tau_1]*(1 - omega_tau_2[tau_2])*value/_timestep;
	func_pointer->get_si_pointer(tau_1 + 1, 0, 0)->value_temp += (1 - omega_tau_1[tau_1])* omega_tau_2[tau_2] * value/ _timestep;
	func_pointer->get_ii_pointer(0, 0, 0)->value_temp += omega_tau_1[tau_1] * omega_tau_2[tau_2] * value/ _timestep;
	return 1;
}

int ss_block::renew()
{
	value = value_temp;
	value_temp = 0;
	return 1;
}

long double ss_block::get_value()
{
	return value;
}