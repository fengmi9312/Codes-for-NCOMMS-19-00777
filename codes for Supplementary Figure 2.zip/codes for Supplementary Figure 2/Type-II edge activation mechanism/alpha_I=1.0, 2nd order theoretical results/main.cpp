#include<iostream>
#include<math.h>
#include"header.h"
#include<fstream>
using namespace std;

int main()
{
	fstream fout("fout.txt", ios::out);
	func* f;
	f = new func(0.01, 603, 10);
	int i=0;
	f->init(0.01);
	f->generate_trans_rec(1.0, 1, 2, 0.5);
//	cout << "i:   " << f->count_i() << endl;
	fout <<i<< " "<< f->count_i() << endl;
	/*cout << "s:   " << f->count_s() << endl;
	cout << "ii:   " << f->count_ii() << endl;
	cout << "si:   " << f->count_si() << endl;
	cout << "ss:   " << f->count_ss() << endl;
	cout << "i+s:         " << f->count_i() + f->count_s() << endl;
	cout << "ii+2si+ss:   " << f->count_ii() + 2 * f->count_si() + f->count_ss() << endl << endl << endl;*/
	for (i = 1; i < 601; i++)
	{
		f->run();
//		cout << "i:   " << f->count_i() << endl;
		fout << (long double)i*0.01 << " " << f->count_i() << endl;
	/*	cout << "s:   " << f->count_s() << endl;
		cout << "ii:   " << f->count_ii() << endl;
		cout << "si:   " << f->count_si() << endl;
		cout << "ss:   " << f->count_ss() << endl;
		cout << "i+s:         " << f->count_i() + f->count_s() << endl;
		cout << "ii+2si+ss:   " << f->count_ii() + 2 * f->count_si() + f->count_ss() << endl << endl << endl;*/
	}
//	system("pause");
	return 1;
}