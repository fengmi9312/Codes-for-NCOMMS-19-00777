#include"network.h"
#include<iostream>
#include<math.h>
#include<fstream>
using namespace std;

long double infect_function[6001];
long double recover_function[6001];
long double trans_infect_function[6001];
int init_in_su(long double alpha1, long double beta1, long double alpha2, long double beta2, long double time_step)
{
	int i, j;
	for (i = 0; i < 6001; i++)
	{
		if (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) == 0) infect_function[i] = 1;
		else infect_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta1, alpha1))) / pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1));
		if (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) == 0) recover_function[i] = 1;
		else recover_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta2, alpha2))) / pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2));
	}
	for (j = 0; j < 6000; j++)
	{
		trans_infect_function[j] = pow(2.718, -pow(((long double)j)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(j + 1))*time_step / beta1, alpha1));
		for (i = 0; i < j; i++)
		{
			trans_infect_function[j] += trans_infect_function[i] * (pow(2.718, -pow(((long double)(j - i - 1))*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(j - i))*time_step / beta1, alpha1)));
		}
	}
	return 1;
}
int main()
{
	fstream fout("result.txt", ios::out);
	int t;
	t = 0;
	long double a1 = 4;
	init_in_su(a1, 1, 2, 0.5, 0.001);
	network net(10000);
	net.creat_random_network(5);
	net.init_array(0.01);
	fout << ((long double)t)*0.001 << " " << net.output_all_array_i(t) << endl;
	while (t <= 6000)
	{
		t++;
		net.dynamic_rule2(recover_function,trans_infect_function,t);
		fout << ((long double)t)*0.001 << " " << net.output_all_array_i(t) << endl;
	}
	return 1;
}

