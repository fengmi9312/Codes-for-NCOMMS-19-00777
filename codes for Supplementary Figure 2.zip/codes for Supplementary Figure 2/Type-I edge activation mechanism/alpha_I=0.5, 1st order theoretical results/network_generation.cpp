#include<iostream>
#include<math.h>
#include"network.h"
using namespace std;
int network::creat_random_network(int ave_degree)
{
	int i,j;
	for(i=0;i<node_amount;i++)
		for(j=0;j<ave_degree;j++)
			add_edge(i,outputfrandnum(node_amount*10)/10,0,1);
	return 1;
}
int network::creat_BA_network(int initnodenum,int stepedgenum)
{
    int i,j,k,t,e,udgr;
	int* p;
	long long int num;
	if(initnodenum<stepedgenum)
	{
		cout<<"error undirected?creatsfnet:initnodenum<stepedgenum!"<<endl;
		return 0;
	}
	if(initnodenum==1);
	else if(initnodenum==2) add_edge1(0,1);
	else if(initnodenum<=0) 
	{
		cout<<"error undirected?creatsfnet:initnodenum<=0!"<<endl;
		return 0;
	}
	else
	{
        for(i=0;i<initnodenum;i++)
        {
	    	j=i+1;
	    	if(j==initnodenum) j=0;
            add_edge1(i,j);
        }
	}
	p = new int[stepedgenum];
	for(i=initnodenum;i<node_amount;i++)
	{
        for(j=0;j<stepedgenum;j++)
        {
	        do{
	    	     num=outputfrandnum(edge_amount*2);
	    	     for(k=0;k<i;k++)
	    	     {
					 udgr=node_pointer[k].degree;
	    	 		 num=num-udgr;
				 	 if(num<0) break;
	    	     }
				 e=0;
				 for(t=0;t<j;t++)
				 {
					 if(p[t]==k)
					 {
						 e=1;
						 break;
					 }
				 }
	         }while(e==1);
			 p[j]=k;
         }
		for(j=0;j<stepedgenum;j++) add_edge1(i,p[j]);
	}
	delete p;
    return 1;
}
int network::creat_nw_network(int other_neighbor_num,int k)
{
	int i,j,m,n,t;
	if(k%2==1)
	{
		cout<<"error network?creat_ws_network: the num k must be even."<<endl;
		return 0;
	}
	for(i=0;i<node_amount;i++)
	{
		for(j=1;j<=k/2;j++)
		{
			m=i+j;
			n=i-j;
			if(m>=node_amount) m=m-node_amount;
			add_edge(i,m,0,1);
		}
	}
	for (i = 0; i<node_amount; i++)
		for (j = 0; j<other_neighbor_num; j++)
			add_edge(i, outputfrandnum(node_amount * 10) / 10, 0, 1);
	return 1;
}

int network::creat_complete_network()
{
	int i, j;
	for (i = 0; i < node_amount - 1; i++)
		for (j = i + 1; j < node_amount; j++)
			add_edge(i, j, 0, 1);
	return 1;
}