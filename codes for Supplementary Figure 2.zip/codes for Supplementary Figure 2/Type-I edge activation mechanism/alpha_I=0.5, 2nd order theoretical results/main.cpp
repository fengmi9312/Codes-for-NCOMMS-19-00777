#include<iostream>
#include"header.h"
#include<fstream>
#include<math.h>
using namespace std;

long double infect_function[601];
long double recover_function[601];
long double count_si_x[601];
long double in[601];
long double su[601];
int degree = 10;
int init_in_su(long double alpha1, long double beta1, long double alpha2, long double beta2, long double time_step)
{
	int i;
	for (i = 0; i < 601; i++)
	{
		if (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) == 0) infect_function[i] = 1;
		else infect_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta1, alpha1))) / pow(2.718, -pow(((long double)i)*time_step / beta1, alpha1));
		if (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) == 0) recover_function[i] = 1;
		else recover_function[i] = (pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2)) - pow(2.718, -pow(((long double)(i + 1))*time_step / beta2, alpha2))) / pow(2.718, -pow(((long double)i)*time_step / beta2, alpha2));
	}
	return 1;
}
int min_int(int i, int j)
{
	if (i <= j) return i;
	else return j;
}
long double recover_(int i)
{
	return recover_function[i];
}
long double recover_i(int i, int j)
{
	return recover_function[i];
}
long double recover_j(int i, int j)
{
	return recover_function[j];
}
long double min_(int i, int j)
{
	return infect_function[min_int(i, j)];
}
long double min_d(int i, int j)
{
	return degree * infect_function[min_int(i, j)];
}
long double min_1d_i(int i, int j)
{
	return (degree - 1) * count_si_x[i] / su[i];
}
long double min_2d_i(int i, int j)
{
	return (degree - 1)*count_si_x[i] / su[i] + infect_function[min_int(i, j)];
}
long double min_1d_j(int i, int j)
{
	return (degree - 1) * count_si_x[j] / su[j];
}
long double min_2d_j(int i, int j)
{
	return (degree - 1)*count_si_x[j] / su[j] + infect_function[min_int(i, j)];
}
long double min_3d(int i)
{
	return degree * count_si_x[i] / su[i];
}
int main()
{
	long double alpha1, beta1, alpha2, beta2;
	string folder_name;
	alpha1 = 0.5;
	alpha2 = 2;
	beta2 = 0.5;
	beta1 = 1;
	fstream fout("result.txt", ios::out);
	int i;
	long double* si[601];
	long double* ss[601];
	long double* ii[601];
	long double* is[601];
	for (i = 0; i < 601; i++)
	{
		si[i] = new long double[601];
		ss[i] = new long double[601];
		ii[i] = new long double[601];
		is[i] = new long double[601];
	}
	long double si_x_lost[601];
	long double si_y_lost[601];
	long double ss_x_lost[601];
	long double ss_y_lost[601];
	long double ii_x_lost[601];
	long double ii_y_lost[601];
	long double is_x_lost[601];
	long double is_y_lost[601];
	long double si_xy_lost;
	long double ss_xy_lost;
	long double ii_xy_lost;
	long double is_xy_lost;
	long double i_lost;
	long double s_lost;
	long double time, i_f;
	init_in_su(alpha1, beta1, alpha2, beta2, 0.01);
	init_array(0.01, in, su, si, ss, ii, is, 601, 0.01);
	i = 0;
	time = ((long double)i)*0.01;
	i_f = count_array(in, i);
	fout << time << " " << i_f << endl;
	for (i = 1; i <= 600; i++)
	{
		count_matrix_x(si, min_, count_si_x, 601, i);
		lost_x(si, min_2d_i, recover_j, 601, si_x_lost, i);
		lost_y(si, min_2d_i, recover_j, 601, si_y_lost, i);
		lost_xy(si, min_2d_i, recover_j, 601, si_xy_lost, i);
		lost_half_x(ss, min_1d_i, min_1d_j, 601, ss_x_lost, i);
		lost_half_xy(ss, min_1d_i, min_1d_j, 601, ss_xy_lost, i);
		lost_half_y(ii, recover_i, recover_j, 601, ii_y_lost, i);
		lost_half_xy(ii, recover_i, recover_j, 601, ii_xy_lost, i);
		i_lost = lost_array(in, recover_, 601, i);
		s_lost = lost_array(su, min_3d, 601, i);
		trans_matrix(si, min_2d_i, recover_j, 601, i);
		trans_half_matrix(ss, min_1d_i, min_1d_j, 601, i);
		trans_half_matrix(ii, recover_i, recover_j, 601, i);
		trans_array(in, recover_, 601, i);
		trans_array(su, min_3d, 601, i);
		give_bound_x(si, ss_x_lost, 601, i);
		give_bound_y(si, ii_y_lost, 601, i);
		si[0][0] = si_xy_lost;
		give_bound_x(ss, si_x_lost, 601, i);
		ss[0][0] = ii_xy_lost;
		give_bound_x(ii, si_y_lost, 601, i);
		ii[0][0] = ss_xy_lost;
		in[0] = s_lost;
		su[0] = i_lost;
		time = ((long double)i)*0.01;
		i_f = count_array(in, i);
		cout << time << " " << i_f << endl;
		fout << time << " " << i_f << endl;
	}
	return 1;
}