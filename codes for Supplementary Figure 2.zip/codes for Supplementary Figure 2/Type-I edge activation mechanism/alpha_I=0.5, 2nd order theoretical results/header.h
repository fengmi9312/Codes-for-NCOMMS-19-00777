#pragma once
#pragma once
#include<iostream>
using namespace std;
int count_matrix_x(long double** matrix, long double(*function)(int i, int j), long double* temp, int len, int area)
{
	int i, j;
	for (i = 0; i < area; i++)
	{
		temp[i] = 0;
		for (j = 0; j < area; j++)
		{
			temp[i] += matrix[i][j] * function(i, j)*0.01;
		}
	}
	return 1;
}
long double count_array(long double* array_pointer, int area)
{
	int i;
	long double temp = 0;
	for (i = 0; i <= area; i++)
		temp += array_pointer[i] * 0.01;
	return temp;
}
long double count_matrix(long double** matrix, int area)
{
	int i, j;
	long double temp = 0;
	for (i = 0; i <= area; i++)
		for (j = 0; j <= area; j++)
			temp += matrix[i][j] * 0.01*0.01;
	return temp;
}
long double count_half_matrix(long double** matrix, int area)
{
	int i, j;
	long double temp = 0;
	for (i = 0; i <= area; i++)
	{
		for (j = 0; j < i; j++) temp += matrix[i][j] * 0.01*0.01;
		for (j = i; j <= area; j++) temp += matrix[j][i] * 0.01*0.01;
	}
	return temp;
}
int trans_matrix(long double** matrix, long double(*function1)(int i, int j), long double(*function2)(int i, int j), int len, int area)
{
	int i, j;
	for (i = area; i > 0; i--)
		for (j = area; j > 0; j--)
		{
			matrix[i][j] = matrix[i - 1][j - 1] * (1 - (function1(i - 1, j - 1) + function2(i - 1, j - 1) - function1(i - 1, j - 1) * function2(i - 1, j - 1)));
		}
	return 1;
}int trans_half_matrix(long double** matrix, long double(*function1)(int i, int j), long double(*function2)(int i, int j), int len, int area)
{
	int i, j;
	for (i = area; i > 0; i--)
		for (j = i; j > 0; j--)
		{
			matrix[i][j] = matrix[i - 1][j - 1] * (1 - (function1(i - 1, j - 1) + function2(i - 1, j - 1) - function1(i - 1, j - 1) * function2(i - 1, j - 1)));
		}
	return 1;
}
int lost_x(long double** matrix, long double(*function1)(int i, int j), long double(*function2)(int i, int j), int len, long double* x_lost, int area)
{
	int i, j;
	long double temp = 0;
	for (i = 0; i < area; i++) x_lost[i] = 0;
	for (i = 0; i < area; i++)
	{
		for (j = 0; j < area; j++) x_lost[i] += matrix[i][j] * function2(i, j) * (1 - function1(i, j));
	}
	return 1;
}
int lost_half_x(long double** matrix, long double(*function1)(int i, int j), long double(*function2)(int i, int j), int len, long double* x_lost, int area)
{
	int i, j;
	long double temp = 0;
	for (i = 0; i < area; i++) x_lost[i] = 0;
	for (i = 0; i < area; i++)
	{
		for (j = 0; j < i; j++) x_lost[i] += matrix[i][j] * function2(i, j) * (1 - function1(i, j));
		for (j = i; j < area; j++) x_lost[i] += matrix[j][i] * function2(i, j) * (1 - function1(i, j));
	}
	return 1;
}
int lost_y(long double** matrix, long double(*function1)(int i, int j), long double(*function2)(int i, int j), int len, long double* y_lost, int area)
{
	int i, j;
	for (i = 0; i < area; i++) y_lost[i] = 0;
	for (i = 0; i < area; i++)
	{
		for (j = 0; j < area; j++) y_lost[j] += matrix[i][j] * function1(i, j) * (1 - function2(i, j));
	}
	return 1;
}
int lost_half_y(long double** matrix, long double(*function1)(int i, int j), long double(*function2)(int i, int j), int len, long double* y_lost, int area)
{
	int i, j;
	for (i = 0; i < area; i++) y_lost[i] = 0;
	for (i = 0; i < area; i++)
	{
		for (j = 0; j < i; j++) y_lost[j] += matrix[i][j] * function1(i, j) * (1 - function2(i, j));
		for (j = i; j < area; j++) y_lost[j] += matrix[j][i] * function1(i, j) * (1 - function2(i, j));
	}
	return 1;
}
int lost_xy(long double** matrix, long double(*function1)(int i, int j), long double(*function2)(int i, int j), int len, long double& xy_lost, int area)
{
	int i, j;
	xy_lost = 0;
	for (i = 0; i < area; i++)
	{
		for (j = 0; j < area; j++) xy_lost += matrix[i][j] * function2(i, j) * function1(i, j);
	}
	return 1;
}
int lost_half_xy(long double** matrix, long double(*function1)(int i, int j), long double(*function2)(int i, int j), int len, long double& xy_lost, int area)
{
	int i, j;
	xy_lost = 0;
	for (i = 0; i < area; i++)
	{
		for (j = 0; j < i; j++) xy_lost += matrix[i][j] * function2(i, j) * function1(i, j);
		for (j = i; j < area; j++) xy_lost += matrix[j][i] * function2(i, j) * function1(i, j);
	}
	return 1;
}
int give_bound_x(long double** matrix, long double* value, int len, int area)
{
	int i;
	for (i = 0; i < area; i++) matrix[i + 1][0] = value[i];
	return 1;
}
int give_bound_y(long double** matrix, long double* value, int len, int area)
{
	int j;
	for (j = 0; j < area; j++) matrix[0][j + 1] = value[j];
	return 1;
}
int give_bound_xy(long double** matrix, long double value)
{
	int j;
	matrix[0][0] = value;
	return 1;
}
int trans_array(long double* array_pointer, long double(*function)(int i), int len, int area)
{
	int i;
	for (i = area; i > 0; i--)
	{
		array_pointer[i] = array_pointer[i - 1] * (1 - function(i - 1));
	}
	return 1;
}
long double lost_array(long double* array_pointer, long double(*function)(int i), int len, int area)
{
	int i;
	long double array_lost = 0;
	for (i = 0; i < area; i++)
	{
		array_lost += array_pointer[i] * function(i);
	}
	return array_lost;
}
int init_array(long double a, long double* ii, long double* ss, long double** aa, long double** bb, long double** cc, long double** dd, int len, long double time_step)
{
	int i, j;
	for (i = 0; i < len; i++)
	{
		if (i == 0)
		{
			ii[i] = a / time_step;
			ss[i] = (1 - a) / time_step;
		}
		else
		{
			ii[i] = 0;
			ss[i] = 0;
		}
		for (j = 0; j < len; j++)
		{
			if (i == 0 && j == 0)
			{
				aa[i][j] = a * (1 - a) / time_step / time_step;
				bb[i][j] = (1 - a)*(1 - a) / time_step / time_step;
				cc[i][j] = a * a / time_step / time_step;
				dd[i][j] = (1 - a)*a / time_step / time_step;
			}
			else
			{
				aa[i][j] = 0;
				bb[i][j] = 0;
				cc[i][j] = 0;
				dd[i][j] = 0;
			}
		}
	}
	return 1;
}