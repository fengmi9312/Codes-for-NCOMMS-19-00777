#include<iostream>
#include<fstream>
#include<string>
#include<math.h>
#include<fstream>
#include"network.h"
using namespace std;



long double gamma0 = 0, a2 = 0, b2 = 0.5;
long double infection()
{
	return 1.0 - pow(((long double)outputfrandnum(100000)) / 100000.0, 1.0 / gamma0);
}

long double recovery()
{
	return b2 * pow((log(100000.0) - log((long double)outputfrandnum(100000))) / log(2.718), 1 / a2);
}
int main()
{
	fstream fout05("05.txt", ios::out);
	fstream fout10("10.txt", ios::out);
	fstream fout20("20.txt", ios::out);
	fstream fout40("40.txt", ios::out);
	int i,j,ppp,ddd;
	int len;
	long double recovery_rate;
	long double average;
	long double timestep;
	long double* eout;
	network net(10);
	net.import_1100(1, 2426, 16631);
	int i_init[5001];
	int r_init[1];
	r_init[0] = 0;
	i_init[0] = 1213;
	int temp_, y,k;
	for (i = 1; i <= i_init[0]; i++)
	{
		do {
			y = 0;
			temp_ = outputfrandnum(net.output_node_amount());
			for (j = 1; j < i; j++)
			{
				if (i_init[j] == temp_) y = 1;
			}
		} while (y == 1);
		i_init[i] = temp_;
	}
	for (ppp = 1; ppp <= 4; ppp++)
	{
		if(ppp==1) a2 = 0.5;
		else if (ppp == 2) a2 = 1.0;
		else if (ppp == 3) a2 = 2.0;
		else a2 = 4.0;
		for (ddd = 1; ddd <= 200; ddd++)
		{
			recovery_rate = 1.0 / ((b2 / a2)*tgamma(1.0 / a2));
			gamma0 = (((long double)ddd) / 200.0)*recovery_rate;
			net.t_sis_spread_new_mul(infection, recovery, 0.01, 11000, 1, i_init);
			eout = net.output_new_p_t(len, timestep);
			average = 0;
			for (i = 10001; i <= 11000; i++) average += eout[i];
			average /= 1000.0;
		//	cout << ((long double)ddd) / 200.0 << " " << average << endl;
			if (ppp == 1) fout05 << ((long double)ddd)/200.0 << " " << average << endl;
			else if (ppp == 2) fout10 << ((long double)ddd) / 200.0 << " " << average << endl;
			else if (ppp == 3) fout20 << ((long double)ddd) / 200.0 << " " << average << endl;
			else fout40 << ((long double)ddd) / 200.0 << " " << average << endl;
			delete eout;
		}
	}
	fout05.close();
	fout10.close();
	fout20.close();
	fout40.close();
	return 1;
}