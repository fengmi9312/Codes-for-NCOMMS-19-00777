#include<iostream>
#include<math.h>
#include"network.h"
using namespace std;
int network::empty_all_state()
{
	int i;
	edge* edgep;
	for(i=0;i<node_amount;i++)
	{
		node_pointer[i].state=0;
		node_pointer[i].time = -1;
		node_pointer[i].b_time = 0;
		edgep=node_pointer[i].first_edge_pointer;
		while(edgep)
		{
			edgep->activity=0;
			edgep->time = -1;
			edgep->b_time = 0;
			edgep=edgep->next_edge;
		}
	}
	node_infected_amount=0;
	node_susceptible_amount=node_amount;
	network_time = 0;
	return 1;
}
int network::sis_trans_state_t(int node_num,long double (*infection_time)(),long double (*recovery_time)())
{
	edge* edgep0=node_pointer[node_num].first_edge_pointer;
	if(node_pointer[node_num].state==1)
	{
		node_pointer[node_num].state=0;
		node_pointer[node_num].time=-1;
		node_infected_amount--;
		node_susceptible_amount++;
	}
	else if(node_pointer[node_num].state==0)
	{
		node_pointer[node_num].state=1;
		node_pointer[node_num].time=recovery_time()+network_time;
		node_infected_amount++;
		node_susceptible_amount--;
	}
	else
	{
//		cout<<"error network?asyn_sis_trans_state:state wrong!"<<endl;
		return 0;
	}
	node_pointer[node_num].b_time=network_time;
	while(edgep0)
	{
		trans_activity_t(edgep0,infection_time);
		edgep0=edgep0->next_edge;
	}
	return 1;
}
int network::sis_trans_state_t1(int node_num, long double(*recovery_time)())
{
	if (node_pointer[node_num].state == 1)
	{
		node_pointer[node_num].state = 0;
		node_pointer[node_num].time = -1;
		node_infected_amount--;
		node_susceptible_amount++;
	}
	else if (node_pointer[node_num].state == 0)
	{
		node_pointer[node_num].state = 1;
		node_pointer[node_num].time = recovery_time() + network_time;
		node_infected_amount++;
		node_susceptible_amount--;
	}
	else
	{
//		cout << "error network?asyn_sis_trans_state:state wrong!" << endl;
		return 0;
	}
	node_pointer[node_num].b_time = network_time;
	return 1;
}